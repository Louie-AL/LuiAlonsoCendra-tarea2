﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            cmbx_RegSuc_estado.Items.Add("Activo");
            cmbx_RegSuc_estado.Items.Add("Inactivo");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_RegSuc_Cancelar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();   
        }

        private void btn_RegSuc_Agregar_Click(object sender, EventArgs e)
        {
            try
            {
                bool duplicadoSucursal = false;

                Variables.id_Sucursal = int.Parse(txtbx_RegSuc_id.Text);

                for (int j_cs = 0; j_cs < Variables.contadorSucursales; j_cs++)
                {
                    if (Variables.id_Sucursal == Variables.arregloSucursales[j_cs].idSucursal)
                    {
                        duplicadoSucursal = true;
                    }
                }

                if (duplicadoSucursal)
                {
                    MessageBox.Show("Identificador repetido. Por favor, ingrese un id valido.");
                    return;
                }

                Variables.nombre_Sucursal = txtbx_RegSuc_nombre.Text;
                Variables.direccion_Sucursal = txtbx_RegSuc_direccion.Text;
                Variables.str_estado_Sucursal = cmbx_RegSuc_estado.Text;
                if (Variables.str_estado_Sucursal != "Activo")
                {
                    Variables.estado_Sucursal = false;
                }
                else
                {
                    Variables.estado_Sucursal = true;
                }
                Variables.telefono_Sucursal = txtbx_RegSuc_tel.Text;


                Variables.arregloSucursales[Variables.contadorSucursales] = new Cls_Sucursales();
                Variables.arregloSucursales[Variables.contadorSucursales].idSucursal = Variables.id_Sucursal;
                Variables.arregloSucursales[Variables.contadorSucursales].nombreSucursal = Variables.nombre_Sucursal;
                Variables.arregloSucursales[Variables.contadorSucursales].direccionSucursal = Variables.direccion_Sucursal;
                Variables.arregloSucursales[Variables.contadorSucursales].estadoSucursal = Variables.estado_Sucursal;
                Variables.arregloSucursales[Variables.contadorSucursales].telefonoSucursal = Variables.telefono_Sucursal;

                Variables.contadorSucursales = Variables.contadorSucursales + 1;


                //Limpiar variables
                Variables.id_Sucursal = 0;
                Variables.nombre_Sucursal = null;
                Variables.direccion_Sucursal = null;
                Variables.str_estado_Sucursal = null;
                Variables.estado_Sucursal = false;
                Variables.telefono_Sucursal = null;

                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error. Volviendo al menu principal.");
                this.Hide();
                Form1 frm = new Form1();
                frm.ShowDialog();
                return;
            }
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }
    }
}
