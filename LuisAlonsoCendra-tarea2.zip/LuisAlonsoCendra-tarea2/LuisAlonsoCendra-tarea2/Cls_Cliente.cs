﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{
    public class Cls_Cliente
    {
        public string idCliente;
        public string nombreCliente;
        public string primerApellidoCliente;
        public string segundoApellidoCliente;
        public DateTime nacimientoCliente;
        public char generoCliente;

        public Cls_Cliente(string idCliente, string nombreCliente, string primerApellidoCliente, string segundoApellidoCliente, DateTime nacimientoCliente, char generoCliente)
        {
            this.idCliente = idCliente ?? throw new ArgumentNullException(nameof(idCliente));
            this.nombreCliente = nombreCliente ?? throw new ArgumentNullException(nameof(nombreCliente));
            this.primerApellidoCliente = primerApellidoCliente ?? throw new ArgumentNullException(nameof(primerApellidoCliente));
            this.segundoApellidoCliente = segundoApellidoCliente ?? throw new ArgumentNullException(nameof(segundoApellidoCliente));
            this.nacimientoCliente = nacimientoCliente;
            this.generoCliente = generoCliente;
        }

        public Cls_Cliente()
        {

        }
    }
}
