﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormCoberturas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_RegCobertura_Titulo = new System.Windows.Forms.Label();
            this.lbl_RegCoberturas_id = new System.Windows.Forms.Label();
            this.lbl_RegCoberturas_desc = new System.Windows.Forms.Label();
            this.lbl_RegCoberturas_idTipoV = new System.Windows.Forms.Label();
            this.lbl_RegCoberturas_estado = new System.Windows.Forms.Label();
            this.lbl_RegCoberturas_monto = new System.Windows.Forms.Label();
            this.txtbx_RegCobertura_id = new System.Windows.Forms.TextBox();
            this.txtbx_RegCobertura_desc = new System.Windows.Forms.TextBox();
            this.txtbx_RegCobertura_idTipoV = new System.Windows.Forms.TextBox();
            this.txtbx_RegCobertura_monto = new System.Windows.Forms.TextBox();
            this.cmbx_RegCoberturas_estado = new System.Windows.Forms.ComboBox();
            this.btn_RegCobertura_Agregar = new System.Windows.Forms.Button();
            this.btn_RegCobertura_Cancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_RegCobertura_Titulo
            // 
            this.lbl_RegCobertura_Titulo.AutoSize = true;
            this.lbl_RegCobertura_Titulo.Location = new System.Drawing.Point(388, 40);
            this.lbl_RegCobertura_Titulo.Name = "lbl_RegCobertura_Titulo";
            this.lbl_RegCobertura_Titulo.Size = new System.Drawing.Size(169, 20);
            this.lbl_RegCobertura_Titulo.TabIndex = 0;
            this.lbl_RegCobertura_Titulo.Text = "Registo de Coberturas";
            // 
            // lbl_RegCoberturas_id
            // 
            this.lbl_RegCoberturas_id.AutoSize = true;
            this.lbl_RegCoberturas_id.Location = new System.Drawing.Point(32, 102);
            this.lbl_RegCoberturas_id.Name = "lbl_RegCoberturas_id";
            this.lbl_RegCoberturas_id.Size = new System.Drawing.Size(97, 20);
            this.lbl_RegCoberturas_id.TabIndex = 1;
            this.lbl_RegCoberturas_id.Text = "Identificador";
            // 
            // lbl_RegCoberturas_desc
            // 
            this.lbl_RegCoberturas_desc.AutoSize = true;
            this.lbl_RegCoberturas_desc.Location = new System.Drawing.Point(32, 162);
            this.lbl_RegCoberturas_desc.Name = "lbl_RegCoberturas_desc";
            this.lbl_RegCoberturas_desc.Size = new System.Drawing.Size(92, 20);
            this.lbl_RegCoberturas_desc.TabIndex = 2;
            this.lbl_RegCoberturas_desc.Text = "Descripcion";
            // 
            // lbl_RegCoberturas_idTipoV
            // 
            this.lbl_RegCoberturas_idTipoV.AutoSize = true;
            this.lbl_RegCoberturas_idTipoV.Location = new System.Drawing.Point(32, 225);
            this.lbl_RegCoberturas_idTipoV.Name = "lbl_RegCoberturas_idTipoV";
            this.lbl_RegCoberturas_idTipoV.Size = new System.Drawing.Size(243, 20);
            this.lbl_RegCoberturas_idTipoV.TabIndex = 3;
            this.lbl_RegCoberturas_idTipoV.Text = "Identificador del Tipo de Vehiculo";
            // 
            // lbl_RegCoberturas_estado
            // 
            this.lbl_RegCoberturas_estado.AutoSize = true;
            this.lbl_RegCoberturas_estado.Location = new System.Drawing.Point(32, 285);
            this.lbl_RegCoberturas_estado.Name = "lbl_RegCoberturas_estado";
            this.lbl_RegCoberturas_estado.Size = new System.Drawing.Size(60, 20);
            this.lbl_RegCoberturas_estado.TabIndex = 4;
            this.lbl_RegCoberturas_estado.Text = "Estado";
            // 
            // lbl_RegCoberturas_monto
            // 
            this.lbl_RegCoberturas_monto.AutoSize = true;
            this.lbl_RegCoberturas_monto.Location = new System.Drawing.Point(32, 345);
            this.lbl_RegCoberturas_monto.Name = "lbl_RegCoberturas_monto";
            this.lbl_RegCoberturas_monto.Size = new System.Drawing.Size(54, 20);
            this.lbl_RegCoberturas_monto.TabIndex = 5;
            this.lbl_RegCoberturas_monto.Text = "Monto";
            // 
            // txtbx_RegCobertura_id
            // 
            this.txtbx_RegCobertura_id.Location = new System.Drawing.Point(282, 96);
            this.txtbx_RegCobertura_id.Name = "txtbx_RegCobertura_id";
            this.txtbx_RegCobertura_id.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCobertura_id.TabIndex = 6;
            // 
            // txtbx_RegCobertura_desc
            // 
            this.txtbx_RegCobertura_desc.Location = new System.Drawing.Point(282, 156);
            this.txtbx_RegCobertura_desc.Name = "txtbx_RegCobertura_desc";
            this.txtbx_RegCobertura_desc.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCobertura_desc.TabIndex = 7;
            // 
            // txtbx_RegCobertura_idTipoV
            // 
            this.txtbx_RegCobertura_idTipoV.Location = new System.Drawing.Point(282, 219);
            this.txtbx_RegCobertura_idTipoV.Name = "txtbx_RegCobertura_idTipoV";
            this.txtbx_RegCobertura_idTipoV.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCobertura_idTipoV.TabIndex = 8;
            // 
            // txtbx_RegCobertura_monto
            // 
            this.txtbx_RegCobertura_monto.Location = new System.Drawing.Point(282, 339);
            this.txtbx_RegCobertura_monto.Name = "txtbx_RegCobertura_monto";
            this.txtbx_RegCobertura_monto.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCobertura_monto.TabIndex = 9;
            // 
            // cmbx_RegCoberturas_estado
            // 
            this.cmbx_RegCoberturas_estado.FormattingEnabled = true;
            this.cmbx_RegCoberturas_estado.Location = new System.Drawing.Point(282, 277);
            this.cmbx_RegCoberturas_estado.Name = "cmbx_RegCoberturas_estado";
            this.cmbx_RegCoberturas_estado.Size = new System.Drawing.Size(275, 28);
            this.cmbx_RegCoberturas_estado.TabIndex = 10;
            this.cmbx_RegCoberturas_estado.SelectedIndexChanged += new System.EventHandler(this.cmbx_RegCoberturas_estado_SelectedIndexChanged);
            // 
            // btn_RegCobertura_Agregar
            // 
            this.btn_RegCobertura_Agregar.Location = new System.Drawing.Point(627, 156);
            this.btn_RegCobertura_Agregar.Name = "btn_RegCobertura_Agregar";
            this.btn_RegCobertura_Agregar.Size = new System.Drawing.Size(100, 36);
            this.btn_RegCobertura_Agregar.TabIndex = 11;
            this.btn_RegCobertura_Agregar.Text = "Agregar";
            this.btn_RegCobertura_Agregar.UseVisualStyleBackColor = true;
            this.btn_RegCobertura_Agregar.Click += new System.EventHandler(this.btn_RegCobertura_Agregar_Click);
            // 
            // btn_RegCobertura_Cancelar
            // 
            this.btn_RegCobertura_Cancelar.Location = new System.Drawing.Point(627, 277);
            this.btn_RegCobertura_Cancelar.Name = "btn_RegCobertura_Cancelar";
            this.btn_RegCobertura_Cancelar.Size = new System.Drawing.Size(100, 36);
            this.btn_RegCobertura_Cancelar.TabIndex = 12;
            this.btn_RegCobertura_Cancelar.Text = "Cancelar";
            this.btn_RegCobertura_Cancelar.UseVisualStyleBackColor = true;
            this.btn_RegCobertura_Cancelar.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormCoberturas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_RegCobertura_Cancelar);
            this.Controls.Add(this.btn_RegCobertura_Agregar);
            this.Controls.Add(this.cmbx_RegCoberturas_estado);
            this.Controls.Add(this.txtbx_RegCobertura_monto);
            this.Controls.Add(this.txtbx_RegCobertura_idTipoV);
            this.Controls.Add(this.txtbx_RegCobertura_desc);
            this.Controls.Add(this.txtbx_RegCobertura_id);
            this.Controls.Add(this.lbl_RegCoberturas_monto);
            this.Controls.Add(this.lbl_RegCoberturas_estado);
            this.Controls.Add(this.lbl_RegCoberturas_idTipoV);
            this.Controls.Add(this.lbl_RegCoberturas_desc);
            this.Controls.Add(this.lbl_RegCoberturas_id);
            this.Controls.Add(this.lbl_RegCobertura_Titulo);
            this.Name = "FormCoberturas";
            this.Text = "FormCoberturas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_RegCobertura_Titulo;
        private System.Windows.Forms.Label lbl_RegCoberturas_id;
        private System.Windows.Forms.Label lbl_RegCoberturas_desc;
        private System.Windows.Forms.Label lbl_RegCoberturas_idTipoV;
        private System.Windows.Forms.Label lbl_RegCoberturas_estado;
        private System.Windows.Forms.Label lbl_RegCoberturas_monto;
        private System.Windows.Forms.TextBox txtbx_RegCobertura_id;
        private System.Windows.Forms.TextBox txtbx_RegCobertura_desc;
        private System.Windows.Forms.TextBox txtbx_RegCobertura_idTipoV;
        private System.Windows.Forms.TextBox txtbx_RegCobertura_monto;
        private System.Windows.Forms.ComboBox cmbx_RegCoberturas_estado;
        private System.Windows.Forms.Button btn_RegCobertura_Agregar;
        private System.Windows.Forms.Button btn_RegCobertura_Cancelar;
    }
}