﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormConsultarVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_ConsultarVehiculo = new System.Windows.Forms.DataGridView();
            this.btn_ConsultarVehiculo = new System.Windows.Forms.Button();
            this.lbl_ConsultarVehiculo = new System.Windows.Forms.Label();
            this.Placa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Marca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Modelo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id_Tipo_Vehiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Costo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kilometraje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarVehiculo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_ConsultarVehiculo
            // 
            this.dgv_ConsultarVehiculo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ConsultarVehiculo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Placa,
            this.Marca,
            this.Modelo,
            this.Id_Tipo_Vehiculo,
            this.Costo,
            this.Kilometraje});
            this.dgv_ConsultarVehiculo.Location = new System.Drawing.Point(12, 99);
            this.dgv_ConsultarVehiculo.Name = "dgv_ConsultarVehiculo";
            this.dgv_ConsultarVehiculo.RowHeadersWidth = 62;
            this.dgv_ConsultarVehiculo.RowTemplate.Height = 28;
            this.dgv_ConsultarVehiculo.Size = new System.Drawing.Size(776, 241);
            this.dgv_ConsultarVehiculo.TabIndex = 0;
            // 
            // btn_ConsultarVehiculo
            // 
            this.btn_ConsultarVehiculo.Location = new System.Drawing.Point(645, 364);
            this.btn_ConsultarVehiculo.Name = "btn_ConsultarVehiculo";
            this.btn_ConsultarVehiculo.Size = new System.Drawing.Size(100, 39);
            this.btn_ConsultarVehiculo.TabIndex = 1;
            this.btn_ConsultarVehiculo.Text = "Salir";
            this.btn_ConsultarVehiculo.UseVisualStyleBackColor = true;
            this.btn_ConsultarVehiculo.Click += new System.EventHandler(this.btn_ConsultarVehiculo_Click);
            // 
            // lbl_ConsultarVehiculo
            // 
            this.lbl_ConsultarVehiculo.AutoSize = true;
            this.lbl_ConsultarVehiculo.Location = new System.Drawing.Point(351, 41);
            this.lbl_ConsultarVehiculo.Name = "lbl_ConsultarVehiculo";
            this.lbl_ConsultarVehiculo.Size = new System.Drawing.Size(159, 20);
            this.lbl_ConsultarVehiculo.TabIndex = 2;
            this.lbl_ConsultarVehiculo.Text = "Consulta de Vehiculo";
            // 
            // Placa
            // 
            this.Placa.HeaderText = "Placa";
            this.Placa.MinimumWidth = 8;
            this.Placa.Name = "Placa";
            this.Placa.Width = 150;
            // 
            // Marca
            // 
            this.Marca.HeaderText = "Marca";
            this.Marca.MinimumWidth = 8;
            this.Marca.Name = "Marca";
            this.Marca.Width = 150;
            // 
            // Modelo
            // 
            this.Modelo.HeaderText = "Modelo";
            this.Modelo.MinimumWidth = 8;
            this.Modelo.Name = "Modelo";
            this.Modelo.Width = 150;
            // 
            // Id_Tipo_Vehiculo
            // 
            this.Id_Tipo_Vehiculo.HeaderText = "Id_Tipo_Vehiculo";
            this.Id_Tipo_Vehiculo.MinimumWidth = 8;
            this.Id_Tipo_Vehiculo.Name = "Id_Tipo_Vehiculo";
            this.Id_Tipo_Vehiculo.Width = 150;
            // 
            // Costo
            // 
            this.Costo.HeaderText = "Costo";
            this.Costo.MinimumWidth = 8;
            this.Costo.Name = "Costo";
            this.Costo.Width = 150;
            // 
            // Kilometraje
            // 
            this.Kilometraje.HeaderText = "Kilometraje";
            this.Kilometraje.MinimumWidth = 8;
            this.Kilometraje.Name = "Kilometraje";
            this.Kilometraje.Width = 150;
            // 
            // FormConsultarVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_ConsultarVehiculo);
            this.Controls.Add(this.btn_ConsultarVehiculo);
            this.Controls.Add(this.dgv_ConsultarVehiculo);
            this.Name = "FormConsultarVehiculo";
            this.Text = "FormConsultarVehiculo";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarVehiculo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_ConsultarVehiculo;
        private System.Windows.Forms.Button btn_ConsultarVehiculo;
        private System.Windows.Forms.Label lbl_ConsultarVehiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Placa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Marca;
        private System.Windows.Forms.DataGridViewTextBoxColumn Modelo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_Tipo_Vehiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Costo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kilometraje;
    }
}