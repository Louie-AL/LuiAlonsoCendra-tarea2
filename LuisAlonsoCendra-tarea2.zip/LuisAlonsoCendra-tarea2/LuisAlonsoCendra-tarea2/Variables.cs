﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{
    public class Variables
    {

        public static string OpcionMenu;
        public static string OpcionSubMenu;
        public static bool flag = true;
        public static bool flagInternal = true;

        //Contadores
        public static int contadorSucursales = 0;
        public static int contadorCliente = 0;
        public static int contadorTipoV = 0;
        public static int contadorVehiculo = 0;
        public static int contadorVS = 0;
        public static int contadorCoberturas = 0;


        public static int contador5 = 0;
        public static int contador6 = 0;
        public static int contador7 = 0;
        public static int contador8 = 0;
        public static int contadorC = 0;


        public static Cls_Sucursales[] arregloSucursales = new Cls_Sucursales[20];
        public static Cls_Cliente[] arregloCliente = new Cls_Cliente[20];
        public static Cls_TipoVehiculo[] arregloTipoVehiculo = new Cls_TipoVehiculo[20];
        public static Cls_Vehiculo[] arregloVehiculo = new Cls_Vehiculo[20];
        public static VehiculoSucursal[] arregloVehiculoSucursal = new VehiculoSucursal[20];
        public static Cls_Coberturas[] arregloCobertura = new Cls_Coberturas[20];
        public static Cls_Vehiculo[] arregloVehiculo_Asignacion = new Cls_Vehiculo[10];

        //Variables de Sucursal
        public static int id_Sucursal = 0;
        public static string nombre_Sucursal = null;
        public static string direccion_Sucursal = null;
        public static string str_estado_Sucursal = null;
        public static bool estado_Sucursal = false;
        public static string telefono_Sucursal = null;

        //Variables de Clientes
        public static string id_Cliente = null;
        public static string nombre_Cliente = null;
        public static string primer_ApellidoCliente = null;
        public static string segundo_ApellidoCliente = null;
        public static int dia = 0;
        public static int mes = 0;
        public static int ano = 0;
        public static DateTime nacimiento_Cliente;
        public static char genero_Cliente;

        //Variables de Tipo de Vehiculo
        public static string id_TipoV = null;
        public static string descripcion_TipoV = null;
        public static string str_estado_TipoV = null;
        public static bool estado_TipoV = false;

        //Variables de Vehiculo
        public static string placa_Vehiculo = null;
        public static string marca_Vehiculo = null;
        public static string modelo_Vehiculo = null;
        public static string IdTipo_Vehiculo_int = null;
        public static Cls_TipoVehiculo IdTipo_Vehiculo_obj = new Cls_TipoVehiculo();
        public static int costo_Vehiculo = 0;
        public static int kilometraje_Vehiculo = 0;

        //Variables de Cobertura
        public static string id_Cobertura = null;
        public static string descripcion_Cobertura = null;
        public static string IdTipo_Vehiculo_int_Cobertura = null;
        public static Cls_TipoVehiculo idTipoVehiculo_Cobertura = new Cls_TipoVehiculo();
        public static string str_estado_Cobertura = null;
        public static bool estado_Cobertura = false;
        public static int monto_Cobertura = 0;


        //Variables de Vehiculo por Sucursal
        public static int id_Asignacion = 0;
        public static int dia_Asignacion = 0;
        public static int mes_Asignacion = 0;
        public static int ano_Asignacion = 0;
        public static DateTime fecha_Asignacion;
        public static Cls_Sucursales Sucursal_Asignacion = null;

    }
}
