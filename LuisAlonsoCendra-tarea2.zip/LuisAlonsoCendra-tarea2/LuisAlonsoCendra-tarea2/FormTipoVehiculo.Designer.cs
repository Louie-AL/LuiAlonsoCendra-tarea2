﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormTipoVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_RegTipoV_Titulo = new System.Windows.Forms.Label();
            this.lbl_RegTipoV_id = new System.Windows.Forms.Label();
            this.lbl_RegTipoV_descr = new System.Windows.Forms.Label();
            this.lbl_RegTipoV_Estado = new System.Windows.Forms.Label();
            this.txtbx_RegTipoV_id = new System.Windows.Forms.TextBox();
            this.txtbx_RegTipoV_desc = new System.Windows.Forms.TextBox();
            this.cmbx_RegTipoV_estado = new System.Windows.Forms.ComboBox();
            this.btn_RegTipoV_Agregar = new System.Windows.Forms.Button();
            this.btn_RegTipoV_Cancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_RegTipoV_Titulo
            // 
            this.lbl_RegTipoV_Titulo.AutoSize = true;
            this.lbl_RegTipoV_Titulo.Location = new System.Drawing.Point(391, 63);
            this.lbl_RegTipoV_Titulo.Name = "lbl_RegTipoV_Titulo";
            this.lbl_RegTipoV_Titulo.Size = new System.Drawing.Size(212, 20);
            this.lbl_RegTipoV_Titulo.TabIndex = 0;
            this.lbl_RegTipoV_Titulo.Text = "Registro de Tipo de Vehiculo";
            this.lbl_RegTipoV_Titulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_RegTipoV_id
            // 
            this.lbl_RegTipoV_id.AutoSize = true;
            this.lbl_RegTipoV_id.Location = new System.Drawing.Point(135, 156);
            this.lbl_RegTipoV_id.Name = "lbl_RegTipoV_id";
            this.lbl_RegTipoV_id.Size = new System.Drawing.Size(97, 20);
            this.lbl_RegTipoV_id.TabIndex = 1;
            this.lbl_RegTipoV_id.Text = "Identificador";
            // 
            // lbl_RegTipoV_descr
            // 
            this.lbl_RegTipoV_descr.AutoSize = true;
            this.lbl_RegTipoV_descr.Location = new System.Drawing.Point(135, 207);
            this.lbl_RegTipoV_descr.Name = "lbl_RegTipoV_descr";
            this.lbl_RegTipoV_descr.Size = new System.Drawing.Size(92, 20);
            this.lbl_RegTipoV_descr.TabIndex = 2;
            this.lbl_RegTipoV_descr.Text = "Descripcion";
            // 
            // lbl_RegTipoV_Estado
            // 
            this.lbl_RegTipoV_Estado.AutoSize = true;
            this.lbl_RegTipoV_Estado.Location = new System.Drawing.Point(135, 262);
            this.lbl_RegTipoV_Estado.Name = "lbl_RegTipoV_Estado";
            this.lbl_RegTipoV_Estado.Size = new System.Drawing.Size(60, 20);
            this.lbl_RegTipoV_Estado.TabIndex = 3;
            this.lbl_RegTipoV_Estado.Text = "Estado";
            // 
            // txtbx_RegTipoV_id
            // 
            this.txtbx_RegTipoV_id.Location = new System.Drawing.Point(243, 156);
            this.txtbx_RegTipoV_id.Name = "txtbx_RegTipoV_id";
            this.txtbx_RegTipoV_id.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegTipoV_id.TabIndex = 4;
            // 
            // txtbx_RegTipoV_desc
            // 
            this.txtbx_RegTipoV_desc.Location = new System.Drawing.Point(243, 201);
            this.txtbx_RegTipoV_desc.Name = "txtbx_RegTipoV_desc";
            this.txtbx_RegTipoV_desc.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegTipoV_desc.TabIndex = 5;
            // 
            // cmbx_RegTipoV_estado
            // 
            this.cmbx_RegTipoV_estado.FormattingEnabled = true;
            this.cmbx_RegTipoV_estado.Location = new System.Drawing.Point(243, 253);
            this.cmbx_RegTipoV_estado.Name = "cmbx_RegTipoV_estado";
            this.cmbx_RegTipoV_estado.Size = new System.Drawing.Size(275, 28);
            this.cmbx_RegTipoV_estado.TabIndex = 6;
            this.cmbx_RegTipoV_estado.SelectedIndexChanged += new System.EventHandler(this.cmbx_RegTipoV_estado_SelectedIndexChanged);
            // 
            // btn_RegTipoV_Agregar
            // 
            this.btn_RegTipoV_Agregar.Location = new System.Drawing.Point(601, 158);
            this.btn_RegTipoV_Agregar.Name = "btn_RegTipoV_Agregar";
            this.btn_RegTipoV_Agregar.Size = new System.Drawing.Size(90, 30);
            this.btn_RegTipoV_Agregar.TabIndex = 7;
            this.btn_RegTipoV_Agregar.Text = "Agregar";
            this.btn_RegTipoV_Agregar.UseVisualStyleBackColor = true;
            this.btn_RegTipoV_Agregar.Click += new System.EventHandler(this.btn_RegTipoV_Agregar_Click);
            // 
            // btn_RegTipoV_Cancelar
            // 
            this.btn_RegTipoV_Cancelar.Location = new System.Drawing.Point(601, 255);
            this.btn_RegTipoV_Cancelar.Name = "btn_RegTipoV_Cancelar";
            this.btn_RegTipoV_Cancelar.Size = new System.Drawing.Size(90, 30);
            this.btn_RegTipoV_Cancelar.TabIndex = 8;
            this.btn_RegTipoV_Cancelar.Text = "Cancelar";
            this.btn_RegTipoV_Cancelar.UseVisualStyleBackColor = true;
            this.btn_RegTipoV_Cancelar.Click += new System.EventHandler(this.btn_RegTipoV_Cancelar_Click);
            // 
            // FormTipoVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_RegTipoV_Cancelar);
            this.Controls.Add(this.btn_RegTipoV_Agregar);
            this.Controls.Add(this.cmbx_RegTipoV_estado);
            this.Controls.Add(this.txtbx_RegTipoV_desc);
            this.Controls.Add(this.txtbx_RegTipoV_id);
            this.Controls.Add(this.lbl_RegTipoV_Estado);
            this.Controls.Add(this.lbl_RegTipoV_descr);
            this.Controls.Add(this.lbl_RegTipoV_id);
            this.Controls.Add(this.lbl_RegTipoV_Titulo);
            this.Name = "FormTipoVehiculo";
            this.Text = "FormTipoVehiculo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_RegTipoV_Titulo;
        private System.Windows.Forms.Label lbl_RegTipoV_id;
        private System.Windows.Forms.Label lbl_RegTipoV_descr;
        private System.Windows.Forms.Label lbl_RegTipoV_Estado;
        private System.Windows.Forms.TextBox txtbx_RegTipoV_id;
        private System.Windows.Forms.TextBox txtbx_RegTipoV_desc;
        private System.Windows.Forms.ComboBox cmbx_RegTipoV_estado;
        private System.Windows.Forms.Button btn_RegTipoV_Agregar;
        private System.Windows.Forms.Button btn_RegTipoV_Cancelar;
    }
}