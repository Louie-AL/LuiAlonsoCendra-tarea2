﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormCoberturas : Form
    {
        public FormCoberturas()
        {
            InitializeComponent();
            cmbx_RegCoberturas_estado.Items.Add("Activo");
            cmbx_RegCoberturas_estado.Items.Add("Inactivo");
        }

        private void cmbx_RegCoberturas_estado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void btn_RegCobertura_Agregar_Click(object sender, EventArgs e)
        {
            try { 
                bool duplicadoCob = false;    

                Variables.id_Cobertura = txtbx_RegCobertura_id.Text;

                for (int j_cob = 0; j_cob < Variables.contadorCoberturas; j_cob++)
                {
                    if (Variables.id_Cobertura == Variables.arregloCobertura[j_cob].idCobertura)
                    {
                        duplicadoCob = true;
                    }
                }

                if (duplicadoCob)
                {
                    MessageBox.Show("Identificador repetido. Por favor, ingrese un id valido.");
                    return;
                }

                Variables.descripcion_Cobertura = txtbx_RegCobertura_desc.Text;
                Variables.IdTipo_Vehiculo_int_Cobertura = txtbx_RegCobertura_idTipoV.Text;
                Variables.str_estado_Cobertura = cmbx_RegCoberturas_estado.Text;
                if (Variables.str_estado_Sucursal != "Activo")
                {
                    Variables.estado_Cobertura = false;
                }
                else
                {
                    Variables.estado_Cobertura = true;
                }
                Variables.monto_Cobertura = int.Parse(txtbx_RegCobertura_monto.Text);

                Variables.arregloCobertura[Variables.contadorCoberturas] = new Cls_Coberturas();
                Variables.arregloCobertura[Variables.contadorCoberturas].idCobertura = Variables.id_Cobertura;
                Variables.arregloCobertura[Variables.contadorCoberturas].descripcionCobertura = Variables.descripcion_Cobertura;
                Variables.arregloCobertura[Variables.contadorCoberturas].idTipoVehiculo = new Cls_TipoVehiculo(); //***********************
                Variables.arregloCobertura[Variables.contadorCoberturas].estadoCobertura = Variables.estado_Cobertura;
                Variables.arregloCobertura[Variables.contadorCoberturas].montoCobertura = Variables.monto_Cobertura;

                Variables.contadorCoberturas = Variables.contadorCoberturas + 1;

                //Limpiar Variables 
                Variables.id_Cobertura = null;
                Variables.descripcion_Cobertura = null;
                Variables.IdTipo_Vehiculo_int_Cobertura = null;
                Variables.idTipoVehiculo_Cobertura = new Cls_TipoVehiculo();
                Variables.str_estado_Cobertura = null;
                Variables.estado_Cobertura = false;
                Variables.monto_Cobertura = 0;

                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error. Volviendo al menu principal.");
                this.Hide();
                Form1 frm = new Form1();
                frm.ShowDialog();
                return;
            }

        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

    }
}
