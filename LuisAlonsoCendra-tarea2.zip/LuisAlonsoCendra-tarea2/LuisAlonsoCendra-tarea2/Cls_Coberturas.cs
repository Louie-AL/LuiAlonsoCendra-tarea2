﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{
    public class Cls_Coberturas
    {
        public string idCobertura;
        public string descripcionCobertura;
        public Cls_TipoVehiculo idTipoVehiculo;
        public bool estadoCobertura;
        public int montoCobertura;

        public Cls_Coberturas(string idCobertura, string descripcionCobertura, Cls_TipoVehiculo idTipoVehiculo, bool estadoCobertura, int montoCobertura)
        {
            this.idCobertura = idCobertura;
            this.descripcionCobertura = descripcionCobertura;
            this.idTipoVehiculo = idTipoVehiculo;
            this.estadoCobertura = estadoCobertura;
            this.montoCobertura = montoCobertura;
        }

        public Cls_Coberturas()
        {

        }

    }
}
