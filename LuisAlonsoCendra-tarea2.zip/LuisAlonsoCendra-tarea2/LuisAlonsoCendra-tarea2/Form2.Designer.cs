﻿namespace LuisAlonsoCendra_tarea2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_RegSuc_Titulo = new System.Windows.Forms.Label();
            this.lbl_RegSuc_id = new System.Windows.Forms.Label();
            this.lbl_RegSuc_Nombre = new System.Windows.Forms.Label();
            this.lbl_RegSuc_Direccion = new System.Windows.Forms.Label();
            this.lbl_RegSuc_Estado = new System.Windows.Forms.Label();
            this.lbl_RegSuc_Telefono = new System.Windows.Forms.Label();
            this.btn_RegSuc_Agregar = new System.Windows.Forms.Button();
            this.btn_RegSuc_Cancelar = new System.Windows.Forms.Button();
            this.cmbx_RegSuc_estado = new System.Windows.Forms.ComboBox();
            this.txtbx_RegSuc_id = new System.Windows.Forms.TextBox();
            this.txtbx_RegSuc_nombre = new System.Windows.Forms.TextBox();
            this.txtbx_RegSuc_direccion = new System.Windows.Forms.TextBox();
            this.txtbx_RegSuc_tel = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_RegSuc_Titulo
            // 
            this.lbl_RegSuc_Titulo.AutoSize = true;
            this.lbl_RegSuc_Titulo.Location = new System.Drawing.Point(316, 26);
            this.lbl_RegSuc_Titulo.Name = "lbl_RegSuc_Titulo";
            this.lbl_RegSuc_Titulo.Size = new System.Drawing.Size(174, 20);
            this.lbl_RegSuc_Titulo.TabIndex = 0;
            this.lbl_RegSuc_Titulo.Text = "Registro de Sucursales";
            this.lbl_RegSuc_Titulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_RegSuc_id
            // 
            this.lbl_RegSuc_id.AutoSize = true;
            this.lbl_RegSuc_id.Location = new System.Drawing.Point(97, 113);
            this.lbl_RegSuc_id.Name = "lbl_RegSuc_id";
            this.lbl_RegSuc_id.Size = new System.Drawing.Size(97, 20);
            this.lbl_RegSuc_id.TabIndex = 1;
            this.lbl_RegSuc_id.Text = "Identificador";
            // 
            // lbl_RegSuc_Nombre
            // 
            this.lbl_RegSuc_Nombre.AutoSize = true;
            this.lbl_RegSuc_Nombre.Location = new System.Drawing.Point(97, 157);
            this.lbl_RegSuc_Nombre.Name = "lbl_RegSuc_Nombre";
            this.lbl_RegSuc_Nombre.Size = new System.Drawing.Size(65, 20);
            this.lbl_RegSuc_Nombre.TabIndex = 2;
            this.lbl_RegSuc_Nombre.Text = "Nombre";
            // 
            // lbl_RegSuc_Direccion
            // 
            this.lbl_RegSuc_Direccion.AutoSize = true;
            this.lbl_RegSuc_Direccion.Location = new System.Drawing.Point(97, 199);
            this.lbl_RegSuc_Direccion.Name = "lbl_RegSuc_Direccion";
            this.lbl_RegSuc_Direccion.Size = new System.Drawing.Size(75, 20);
            this.lbl_RegSuc_Direccion.TabIndex = 3;
            this.lbl_RegSuc_Direccion.Text = "Direccion";
            this.lbl_RegSuc_Direccion.Click += new System.EventHandler(this.label4_Click);
            // 
            // lbl_RegSuc_Estado
            // 
            this.lbl_RegSuc_Estado.AutoSize = true;
            this.lbl_RegSuc_Estado.Location = new System.Drawing.Point(97, 246);
            this.lbl_RegSuc_Estado.Name = "lbl_RegSuc_Estado";
            this.lbl_RegSuc_Estado.Size = new System.Drawing.Size(60, 20);
            this.lbl_RegSuc_Estado.TabIndex = 4;
            this.lbl_RegSuc_Estado.Text = "Estado";
            // 
            // lbl_RegSuc_Telefono
            // 
            this.lbl_RegSuc_Telefono.AutoSize = true;
            this.lbl_RegSuc_Telefono.Location = new System.Drawing.Point(97, 289);
            this.lbl_RegSuc_Telefono.Name = "lbl_RegSuc_Telefono";
            this.lbl_RegSuc_Telefono.Size = new System.Drawing.Size(71, 20);
            this.lbl_RegSuc_Telefono.TabIndex = 5;
            this.lbl_RegSuc_Telefono.Text = "Telefono";
            // 
            // btn_RegSuc_Agregar
            // 
            this.btn_RegSuc_Agregar.Location = new System.Drawing.Point(582, 157);
            this.btn_RegSuc_Agregar.Name = "btn_RegSuc_Agregar";
            this.btn_RegSuc_Agregar.Size = new System.Drawing.Size(80, 38);
            this.btn_RegSuc_Agregar.TabIndex = 6;
            this.btn_RegSuc_Agregar.Text = "Agregar";
            this.btn_RegSuc_Agregar.UseVisualStyleBackColor = true;
            this.btn_RegSuc_Agregar.Click += new System.EventHandler(this.btn_RegSuc_Agregar_Click);
            // 
            // btn_RegSuc_Cancelar
            // 
            this.btn_RegSuc_Cancelar.Location = new System.Drawing.Point(582, 246);
            this.btn_RegSuc_Cancelar.Name = "btn_RegSuc_Cancelar";
            this.btn_RegSuc_Cancelar.Size = new System.Drawing.Size(80, 38);
            this.btn_RegSuc_Cancelar.TabIndex = 7;
            this.btn_RegSuc_Cancelar.Text = "Cancelar";
            this.btn_RegSuc_Cancelar.UseVisualStyleBackColor = true;
            this.btn_RegSuc_Cancelar.Click += new System.EventHandler(this.btn_RegSuc_Cancelar_Click);
            // 
            // cmbx_RegSuc_estado
            // 
            this.cmbx_RegSuc_estado.FormattingEnabled = true;
            this.cmbx_RegSuc_estado.Location = new System.Drawing.Point(299, 246);
            this.cmbx_RegSuc_estado.Name = "cmbx_RegSuc_estado";
            this.cmbx_RegSuc_estado.Size = new System.Drawing.Size(200, 28);
            this.cmbx_RegSuc_estado.TabIndex = 8;
            // 
            // txtbx_RegSuc_id
            // 
            this.txtbx_RegSuc_id.Location = new System.Drawing.Point(299, 113);
            this.txtbx_RegSuc_id.Name = "txtbx_RegSuc_id";
            this.txtbx_RegSuc_id.Size = new System.Drawing.Size(200, 26);
            this.txtbx_RegSuc_id.TabIndex = 9;
            // 
            // txtbx_RegSuc_nombre
            // 
            this.txtbx_RegSuc_nombre.Location = new System.Drawing.Point(299, 157);
            this.txtbx_RegSuc_nombre.Name = "txtbx_RegSuc_nombre";
            this.txtbx_RegSuc_nombre.Size = new System.Drawing.Size(200, 26);
            this.txtbx_RegSuc_nombre.TabIndex = 10;
            // 
            // txtbx_RegSuc_direccion
            // 
            this.txtbx_RegSuc_direccion.Location = new System.Drawing.Point(299, 199);
            this.txtbx_RegSuc_direccion.Name = "txtbx_RegSuc_direccion";
            this.txtbx_RegSuc_direccion.Size = new System.Drawing.Size(200, 26);
            this.txtbx_RegSuc_direccion.TabIndex = 11;
            // 
            // txtbx_RegSuc_tel
            // 
            this.txtbx_RegSuc_tel.Location = new System.Drawing.Point(299, 289);
            this.txtbx_RegSuc_tel.Name = "txtbx_RegSuc_tel";
            this.txtbx_RegSuc_tel.Size = new System.Drawing.Size(200, 26);
            this.txtbx_RegSuc_tel.TabIndex = 12;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbx_RegSuc_tel);
            this.Controls.Add(this.txtbx_RegSuc_direccion);
            this.Controls.Add(this.txtbx_RegSuc_nombre);
            this.Controls.Add(this.txtbx_RegSuc_id);
            this.Controls.Add(this.cmbx_RegSuc_estado);
            this.Controls.Add(this.btn_RegSuc_Cancelar);
            this.Controls.Add(this.btn_RegSuc_Agregar);
            this.Controls.Add(this.lbl_RegSuc_Telefono);
            this.Controls.Add(this.lbl_RegSuc_Estado);
            this.Controls.Add(this.lbl_RegSuc_Direccion);
            this.Controls.Add(this.lbl_RegSuc_Nombre);
            this.Controls.Add(this.lbl_RegSuc_id);
            this.Controls.Add(this.lbl_RegSuc_Titulo);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_RegSuc_Titulo;
        private System.Windows.Forms.Label lbl_RegSuc_id;
        private System.Windows.Forms.Label lbl_RegSuc_Nombre;
        private System.Windows.Forms.Label lbl_RegSuc_Direccion;
        private System.Windows.Forms.Label lbl_RegSuc_Estado;
        private System.Windows.Forms.Label lbl_RegSuc_Telefono;
        private System.Windows.Forms.Button btn_RegSuc_Agregar;
        private System.Windows.Forms.Button btn_RegSuc_Cancelar;
        private System.Windows.Forms.ComboBox cmbx_RegSuc_estado;
        private System.Windows.Forms.TextBox txtbx_RegSuc_id;
        private System.Windows.Forms.TextBox txtbx_RegSuc_nombre;
        private System.Windows.Forms.TextBox txtbx_RegSuc_direccion;
        private System.Windows.Forms.TextBox txtbx_RegSuc_tel;
    }
}