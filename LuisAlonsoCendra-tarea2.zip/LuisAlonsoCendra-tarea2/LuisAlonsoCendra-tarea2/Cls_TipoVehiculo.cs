﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{
    public class Cls_TipoVehiculo
    {
        public string idTipoVehiculo;
        public string descripcionTipoVehiculo;
        public bool estadoTipoVehiculo;

        public Cls_TipoVehiculo(string idTipoVehiculo, string descripcionTipoVehiculo, bool estadoTipoVehiculo)
        {
            this.idTipoVehiculo = idTipoVehiculo ?? throw new ArgumentNullException(nameof(idTipoVehiculo));
            this.descripcionTipoVehiculo = descripcionTipoVehiculo ?? throw new ArgumentNullException(nameof(descripcionTipoVehiculo));
            this.estadoTipoVehiculo = estadoTipoVehiculo;
        }
        public Cls_TipoVehiculo()
        {

        }
    }
}