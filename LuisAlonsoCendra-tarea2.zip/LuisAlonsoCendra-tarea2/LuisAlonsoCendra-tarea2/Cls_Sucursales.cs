﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{
    public class Cls_Sucursales
    {
        public int idSucursal;
        public string nombreSucursal;
        public string direccionSucursal;
        public bool estadoSucursal;
        public string telefonoSucursal;

        public Cls_Sucursales(int idSucursal, string nombreSucursal, string direccionSucursal, bool estadoSucursal, string telefonoSucursal)
        {
            this.idSucursal = idSucursal;
            this.nombreSucursal = nombreSucursal ?? throw new ArgumentNullException(nameof(nombreSucursal));
            this.direccionSucursal = direccionSucursal ?? throw new ArgumentNullException(nameof(direccionSucursal));
            this.estadoSucursal = estadoSucursal;
            this.telefonoSucursal = telefonoSucursal ?? throw new ArgumentNullException(nameof(telefonoSucursal));
        }

        public Cls_Sucursales()
        {

        }
    }
}