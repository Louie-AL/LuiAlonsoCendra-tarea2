﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{
    public class VehiculoSucursal
    {
        public int idAsignacion;
        public DateTime fecha;
        public Cls_Sucursales sucursal;
        Cls_Vehiculo[] arregloVehiculo = new Cls_Vehiculo[10];

        public VehiculoSucursal(int idAsignacion, DateTime fecha, Cls_Sucursales sucursal, Cls_Vehiculo[] arregloVehiculo)
        {
            this.idAsignacion = idAsignacion ?? throw new ArgumentNullException(nameof(idAsignacion));
            this.fecha = fecha;
            this.sucursal = sucursal ?? throw new ArgumentNullException(nameof(sucursal));
            this.arregloVehiculo = arregloVehiculo ?? throw new ArgumentNullException(nameof(arregloVehiculo));
        }
        public VehiculoSucursal()
        {
        }

    }
}
