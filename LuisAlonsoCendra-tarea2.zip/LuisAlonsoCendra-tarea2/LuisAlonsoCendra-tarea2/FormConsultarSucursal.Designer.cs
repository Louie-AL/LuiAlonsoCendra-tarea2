﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormConsultarSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_ConsultarSucursal = new System.Windows.Forms.DataGridView();
            this.Identificador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbl_ConsultarSucursal = new System.Windows.Forms.Label();
            this.btn_ConsultarSucursal = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarSucursal)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_ConsultarSucursal
            // 
            this.dgv_ConsultarSucursal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ConsultarSucursal.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Identificador,
            this.Nombre,
            this.Direccion,
            this.Estado,
            this.Telefono});
            this.dgv_ConsultarSucursal.Location = new System.Drawing.Point(12, 93);
            this.dgv_ConsultarSucursal.Name = "dgv_ConsultarSucursal";
            this.dgv_ConsultarSucursal.RowHeadersWidth = 62;
            this.dgv_ConsultarSucursal.RowTemplate.Height = 28;
            this.dgv_ConsultarSucursal.Size = new System.Drawing.Size(776, 239);
            this.dgv_ConsultarSucursal.TabIndex = 0;
            // 
            // Identificador
            // 
            this.Identificador.HeaderText = "Identificador";
            this.Identificador.MinimumWidth = 8;
            this.Identificador.Name = "Identificador";
            this.Identificador.Width = 150;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.MinimumWidth = 8;
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 150;
            // 
            // Direccion
            // 
            this.Direccion.HeaderText = "Direccion";
            this.Direccion.MinimumWidth = 8;
            this.Direccion.Name = "Direccion";
            this.Direccion.Width = 150;
            // 
            // Estado
            // 
            this.Estado.HeaderText = "Estado";
            this.Estado.MinimumWidth = 8;
            this.Estado.Name = "Estado";
            this.Estado.Width = 150;
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.MinimumWidth = 8;
            this.Telefono.Name = "Telefono";
            this.Telefono.Width = 150;
            // 
            // lbl_ConsultarSucursal
            // 
            this.lbl_ConsultarSucursal.AutoSize = true;
            this.lbl_ConsultarSucursal.Location = new System.Drawing.Point(366, 40);
            this.lbl_ConsultarSucursal.Name = "lbl_ConsultarSucursal";
            this.lbl_ConsultarSucursal.Size = new System.Drawing.Size(160, 20);
            this.lbl_ConsultarSucursal.TabIndex = 1;
            this.lbl_ConsultarSucursal.Text = "Consultar Sucursales";
            // 
            // btn_ConsultarSucursal
            // 
            this.btn_ConsultarSucursal.Location = new System.Drawing.Point(596, 370);
            this.btn_ConsultarSucursal.Name = "btn_ConsultarSucursal";
            this.btn_ConsultarSucursal.Size = new System.Drawing.Size(100, 37);
            this.btn_ConsultarSucursal.TabIndex = 2;
            this.btn_ConsultarSucursal.Text = "Salir";
            this.btn_ConsultarSucursal.UseVisualStyleBackColor = true;
            this.btn_ConsultarSucursal.Click += new System.EventHandler(this.btn_ConsultarSucursal_Click);
            // 
            // FormConsultarSucursal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_ConsultarSucursal);
            this.Controls.Add(this.lbl_ConsultarSucursal);
            this.Controls.Add(this.dgv_ConsultarSucursal);
            this.Name = "FormConsultarSucursal";
            this.Text = "FormConsultarSucursal";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarSucursal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_ConsultarSucursal;
        private System.Windows.Forms.DataGridViewTextBoxColumn Identificador;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.Label lbl_ConsultarSucursal;
        private System.Windows.Forms.Button btn_ConsultarSucursal;
    }
}