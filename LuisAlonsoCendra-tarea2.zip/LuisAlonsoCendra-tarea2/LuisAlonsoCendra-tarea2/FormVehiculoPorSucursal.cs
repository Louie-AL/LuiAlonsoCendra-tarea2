﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormVehiculoPorSucursal : Form
    {
        public FormVehiculoPorSucursal()
        {
            InitializeComponent();

            foreach (Cls_Sucursales suc in Variables.arregloSucursales)
            {   
                if(suc != null) { 
                    if(suc.estadoSucursal = true) { 
                        comboBox1.Items.Add("id: [" + suc.idSucursal + "] nombre: [" + suc.nombreSucursal + "] direccion: [" + suc.direccionSucursal + "]");
                    }
                }

            }
            foreach (Cls_Vehiculo veh in Variables.arregloVehiculo)
            {
                if (veh != null)
                {
                    dgv.Rows.Add(veh.idPlacaVehiculo, veh.marcaVehiculo, veh.modeloVehiculo, veh.idTipoVehiculo.descripcionTipoVehiculo, veh.costoAlquilerDia, veh.kilometraje);
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            try {
                bool duplicadoVXP = false;

                Variables.id_Asignacion = int.Parse(txt_idAsign.Text);

                for (int j_vxs = 0; j_vxs < Variables.contadorCliente; j_vxs++)
                {
                    if (Variables.id_Asignacion == Variables.arregloVehiculoSucursal[j_vxs].idAsignacion)
                    {
                        duplicadoVXP = true;
                    }
                }

                if (duplicadoVXP)
                {
                    MessageBox.Show("Identificador repetido. Por favor, ingrese un id valido.");
                    return;
                }

                Variables.dia_Asignacion = int.Parse(txtdia.Text);
                Variables.mes_Asignacion = int.Parse(txtmes.Text);
                Variables.ano_Asignacion = int.Parse(txtano.Text);

                Variables.Sucursal_Asignacion = comboBox1.SelectedItem();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error. Volviendo al menu principal.");
                this.Hide();
                Form1 frm = new Form1();
                frm.ShowDialog();
                return;
            }
}
    }
}
