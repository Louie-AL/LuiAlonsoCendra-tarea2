﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormTipoVehiculo : Form
    {
        public FormTipoVehiculo()
        {
            InitializeComponent();
            cmbx_RegTipoV_estado.Items.Add("Activo");
            cmbx_RegTipoV_estado.Items.Add("Inactivo");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_RegTipoV_Cancelar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void cmbx_RegTipoV_estado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_RegTipoV_Agregar_Click(object sender, EventArgs e)
        {
            try { 
                bool duplicadoTipoV = false;

                Variables.id_TipoV = txtbx_RegTipoV_id.Text;

                for (int j_tv = 0; j_tv < Variables.contadorTipoV; j_tv++)
                {
                    if (Variables.id_TipoV == Variables.arregloTipoVehiculo[j_tv].idTipoVehiculo)
                    {
                        duplicadoTipoV = true;
                    }
                }

                if (duplicadoTipoV)
                {
                    MessageBox.Show("Identificador repetido. Por favor, ingrese un id valido.");
                    return;
                }

                Variables.descripcion_TipoV = txtbx_RegTipoV_desc.Text;
                Variables.str_estado_TipoV = cmbx_RegTipoV_estado.Text;
                if (Variables.str_estado_TipoV != "Activo")
                {
                    Variables.estado_TipoV = false;
                }
                else
                {
                    Variables.estado_TipoV = true;
                }

                Variables.arregloTipoVehiculo[Variables.contadorTipoV] = new Cls_TipoVehiculo();
                Variables.arregloTipoVehiculo[Variables.contadorTipoV].idTipoVehiculo = Variables.id_TipoV;
                Variables.arregloTipoVehiculo[Variables.contadorTipoV].descripcionTipoVehiculo = Variables.descripcion_TipoV;
                Variables.arregloTipoVehiculo[Variables.contadorTipoV].estadoTipoVehiculo = Variables.estado_TipoV;

                Variables.contadorTipoV = Variables.contadorTipoV + 1;

                //Limpiar variables
                Variables.id_TipoV = null;
                Variables.descripcion_TipoV = null;
                Variables.str_estado_TipoV = null;
                Variables.estado_TipoV = false;

                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error. Volviendo al menu principal.");
                this.Hide();
                Form1 frm = new Form1();
                frm.ShowDialog();
                return;
            }

        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }
    }
}
