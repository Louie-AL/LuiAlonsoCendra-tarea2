﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormConsultarCoberturas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_ConsultarCobertura = new System.Windows.Forms.DataGridView();
            this.btn_ConsultarCobertura = new System.Windows.Forms.Button();
            this.lbl_ConsultarCobertura = new System.Windows.Forms.Label();
            this.Identificador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id_TipoVehiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Monto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarCobertura)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_ConsultarCobertura
            // 
            this.dgv_ConsultarCobertura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ConsultarCobertura.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Identificador,
            this.Descripcion,
            this.Id_TipoVehiculo,
            this.Estado,
            this.Monto});
            this.dgv_ConsultarCobertura.Location = new System.Drawing.Point(12, 93);
            this.dgv_ConsultarCobertura.Name = "dgv_ConsultarCobertura";
            this.dgv_ConsultarCobertura.RowHeadersWidth = 62;
            this.dgv_ConsultarCobertura.RowTemplate.Height = 28;
            this.dgv_ConsultarCobertura.Size = new System.Drawing.Size(776, 243);
            this.dgv_ConsultarCobertura.TabIndex = 0;
            // 
            // btn_ConsultarCobertura
            // 
            this.btn_ConsultarCobertura.Location = new System.Drawing.Point(640, 379);
            this.btn_ConsultarCobertura.Name = "btn_ConsultarCobertura";
            this.btn_ConsultarCobertura.Size = new System.Drawing.Size(100, 37);
            this.btn_ConsultarCobertura.TabIndex = 1;
            this.btn_ConsultarCobertura.Text = "Salir";
            this.btn_ConsultarCobertura.UseVisualStyleBackColor = true;
            this.btn_ConsultarCobertura.Click += new System.EventHandler(this.btn_ConsultarCobertura_Click);
            // 
            // lbl_ConsultarCobertura
            // 
            this.lbl_ConsultarCobertura.AutoSize = true;
            this.lbl_ConsultarCobertura.Location = new System.Drawing.Point(350, 43);
            this.lbl_ConsultarCobertura.Name = "lbl_ConsultarCobertura";
            this.lbl_ConsultarCobertura.Size = new System.Drawing.Size(169, 20);
            this.lbl_ConsultarCobertura.TabIndex = 2;
            this.lbl_ConsultarCobertura.Text = "Consulta de Cobertura";
            // 
            // Identificador
            // 
            this.Identificador.HeaderText = "Identificador";
            this.Identificador.MinimumWidth = 8;
            this.Identificador.Name = "Identificador";
            this.Identificador.Width = 150;
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Descripcion";
            this.Descripcion.MinimumWidth = 8;
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.Width = 150;
            // 
            // Id_TipoVehiculo
            // 
            this.Id_TipoVehiculo.HeaderText = "Id_TipoVehiculo";
            this.Id_TipoVehiculo.MinimumWidth = 8;
            this.Id_TipoVehiculo.Name = "Id_TipoVehiculo";
            this.Id_TipoVehiculo.Width = 150;
            // 
            // Estado
            // 
            this.Estado.HeaderText = "Estado";
            this.Estado.MinimumWidth = 8;
            this.Estado.Name = "Estado";
            this.Estado.Width = 150;
            // 
            // Monto
            // 
            this.Monto.HeaderText = "Monto";
            this.Monto.MinimumWidth = 8;
            this.Monto.Name = "Monto";
            this.Monto.Width = 150;
            // 
            // FormConsultarCoberturas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_ConsultarCobertura);
            this.Controls.Add(this.btn_ConsultarCobertura);
            this.Controls.Add(this.dgv_ConsultarCobertura);
            this.Name = "FormConsultarCoberturas";
            this.Text = "FormConsultarCoberturas";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarCobertura)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_ConsultarCobertura;
        private System.Windows.Forms.DataGridViewTextBoxColumn Identificador;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_TipoVehiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Monto;
        private System.Windows.Forms.Button btn_ConsultarCobertura;
        private System.Windows.Forms.Label lbl_ConsultarCobertura;
    }
}