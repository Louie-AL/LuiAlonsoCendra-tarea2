﻿namespace LuisAlonsoCendra_tarea2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_RegCliente_Titulo = new System.Windows.Forms.Label();
            this.lbl_RegCliente_id = new System.Windows.Forms.Label();
            this.lbl_RegCliente_Nombre = new System.Windows.Forms.Label();
            this.lbl_RegCliente_1Apellido = new System.Windows.Forms.Label();
            this.lbl_RegCliente_2Apellido = new System.Windows.Forms.Label();
            this.lbl_RegCliente_FechaNac = new System.Windows.Forms.Label();
            this.lbl_RegCliente_Genero = new System.Windows.Forms.Label();
            this.txtbx_RegCliente_id = new System.Windows.Forms.TextBox();
            this.txtbx_RegCliente_Nombre = new System.Windows.Forms.TextBox();
            this.txtbx_RegCliente_1Ap = new System.Windows.Forms.TextBox();
            this.txtbx_RegCliente_2Ap = new System.Windows.Forms.TextBox();
            this.txtbx_RegCliente_genero = new System.Windows.Forms.TextBox();
            this.btn_RegCliente_Agregar = new System.Windows.Forms.Button();
            this.btn_RegCliente_Cancelar = new System.Windows.Forms.Button();
            this.lbl_RegCliente_Dia = new System.Windows.Forms.Label();
            this.lbl_RegCliente_Mes = new System.Windows.Forms.Label();
            this.lbl_RegCliente_Ano = new System.Windows.Forms.Label();
            this.txtbx_RegCliente_dia = new System.Windows.Forms.TextBox();
            this.txtbx_RegCliente_mes = new System.Windows.Forms.TextBox();
            this.txtbx_RegCliente_ano = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_RegCliente_Titulo
            // 
            this.lbl_RegCliente_Titulo.AutoSize = true;
            this.lbl_RegCliente_Titulo.Location = new System.Drawing.Point(350, 56);
            this.lbl_RegCliente_Titulo.Name = "lbl_RegCliente_Titulo";
            this.lbl_RegCliente_Titulo.Size = new System.Drawing.Size(152, 20);
            this.lbl_RegCliente_Titulo.TabIndex = 0;
            this.lbl_RegCliente_Titulo.Text = "Registro de Clientes";
            this.lbl_RegCliente_Titulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_RegCliente_id
            // 
            this.lbl_RegCliente_id.AutoSize = true;
            this.lbl_RegCliente_id.Location = new System.Drawing.Point(87, 105);
            this.lbl_RegCliente_id.Name = "lbl_RegCliente_id";
            this.lbl_RegCliente_id.Size = new System.Drawing.Size(103, 20);
            this.lbl_RegCliente_id.TabIndex = 1;
            this.lbl_RegCliente_id.Text = "Identificacion";
            // 
            // lbl_RegCliente_Nombre
            // 
            this.lbl_RegCliente_Nombre.AutoSize = true;
            this.lbl_RegCliente_Nombre.Location = new System.Drawing.Point(87, 145);
            this.lbl_RegCliente_Nombre.Name = "lbl_RegCliente_Nombre";
            this.lbl_RegCliente_Nombre.Size = new System.Drawing.Size(65, 20);
            this.lbl_RegCliente_Nombre.TabIndex = 2;
            this.lbl_RegCliente_Nombre.Text = "Nombre";
            // 
            // lbl_RegCliente_1Apellido
            // 
            this.lbl_RegCliente_1Apellido.AutoSize = true;
            this.lbl_RegCliente_1Apellido.Location = new System.Drawing.Point(87, 185);
            this.lbl_RegCliente_1Apellido.Name = "lbl_RegCliente_1Apellido";
            this.lbl_RegCliente_1Apellido.Size = new System.Drawing.Size(114, 20);
            this.lbl_RegCliente_1Apellido.TabIndex = 3;
            this.lbl_RegCliente_1Apellido.Text = "Primer Apellido";
            // 
            // lbl_RegCliente_2Apellido
            // 
            this.lbl_RegCliente_2Apellido.AutoSize = true;
            this.lbl_RegCliente_2Apellido.Location = new System.Drawing.Point(87, 225);
            this.lbl_RegCliente_2Apellido.Name = "lbl_RegCliente_2Apellido";
            this.lbl_RegCliente_2Apellido.Size = new System.Drawing.Size(134, 20);
            this.lbl_RegCliente_2Apellido.TabIndex = 4;
            this.lbl_RegCliente_2Apellido.Text = "Segundo Apellido";
            // 
            // lbl_RegCliente_FechaNac
            // 
            this.lbl_RegCliente_FechaNac.AutoSize = true;
            this.lbl_RegCliente_FechaNac.Location = new System.Drawing.Point(87, 265);
            this.lbl_RegCliente_FechaNac.Name = "lbl_RegCliente_FechaNac";
            this.lbl_RegCliente_FechaNac.Size = new System.Drawing.Size(159, 20);
            this.lbl_RegCliente_FechaNac.TabIndex = 5;
            this.lbl_RegCliente_FechaNac.Text = "Fecha de Nacimiento";
            // 
            // lbl_RegCliente_Genero
            // 
            this.lbl_RegCliente_Genero.AutoSize = true;
            this.lbl_RegCliente_Genero.Location = new System.Drawing.Point(87, 331);
            this.lbl_RegCliente_Genero.Name = "lbl_RegCliente_Genero";
            this.lbl_RegCliente_Genero.Size = new System.Drawing.Size(63, 20);
            this.lbl_RegCliente_Genero.TabIndex = 6;
            this.lbl_RegCliente_Genero.Text = "Genero";
            // 
            // txtbx_RegCliente_id
            // 
            this.txtbx_RegCliente_id.Location = new System.Drawing.Point(308, 105);
            this.txtbx_RegCliente_id.Name = "txtbx_RegCliente_id";
            this.txtbx_RegCliente_id.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCliente_id.TabIndex = 7;
            // 
            // txtbx_RegCliente_Nombre
            // 
            this.txtbx_RegCliente_Nombre.Location = new System.Drawing.Point(308, 145);
            this.txtbx_RegCliente_Nombre.Name = "txtbx_RegCliente_Nombre";
            this.txtbx_RegCliente_Nombre.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCliente_Nombre.TabIndex = 8;
            // 
            // txtbx_RegCliente_1Ap
            // 
            this.txtbx_RegCliente_1Ap.Location = new System.Drawing.Point(308, 185);
            this.txtbx_RegCliente_1Ap.Name = "txtbx_RegCliente_1Ap";
            this.txtbx_RegCliente_1Ap.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCliente_1Ap.TabIndex = 9;
            // 
            // txtbx_RegCliente_2Ap
            // 
            this.txtbx_RegCliente_2Ap.Location = new System.Drawing.Point(308, 225);
            this.txtbx_RegCliente_2Ap.Name = "txtbx_RegCliente_2Ap";
            this.txtbx_RegCliente_2Ap.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCliente_2Ap.TabIndex = 10;
            // 
            // txtbx_RegCliente_genero
            // 
            this.txtbx_RegCliente_genero.Location = new System.Drawing.Point(308, 328);
            this.txtbx_RegCliente_genero.Name = "txtbx_RegCliente_genero";
            this.txtbx_RegCliente_genero.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegCliente_genero.TabIndex = 11;
            // 
            // btn_RegCliente_Agregar
            // 
            this.btn_RegCliente_Agregar.Location = new System.Drawing.Point(647, 175);
            this.btn_RegCliente_Agregar.Name = "btn_RegCliente_Agregar";
            this.btn_RegCliente_Agregar.Size = new System.Drawing.Size(95, 30);
            this.btn_RegCliente_Agregar.TabIndex = 12;
            this.btn_RegCliente_Agregar.Text = "Agregar";
            this.btn_RegCliente_Agregar.UseVisualStyleBackColor = true;
            this.btn_RegCliente_Agregar.Click += new System.EventHandler(this.btn_RegCliente_Agregar_Click);
            // 
            // btn_RegCliente_Cancelar
            // 
            this.btn_RegCliente_Cancelar.Location = new System.Drawing.Point(647, 259);
            this.btn_RegCliente_Cancelar.Name = "btn_RegCliente_Cancelar";
            this.btn_RegCliente_Cancelar.Size = new System.Drawing.Size(95, 26);
            this.btn_RegCliente_Cancelar.TabIndex = 13;
            this.btn_RegCliente_Cancelar.Text = "Cancelar";
            this.btn_RegCliente_Cancelar.UseVisualStyleBackColor = true;
            this.btn_RegCliente_Cancelar.Click += new System.EventHandler(this.btn_RegCliente_Cancelar_Click);
            // 
            // lbl_RegCliente_Dia
            // 
            this.lbl_RegCliente_Dia.AutoSize = true;
            this.lbl_RegCliente_Dia.Location = new System.Drawing.Point(335, 261);
            this.lbl_RegCliente_Dia.Name = "lbl_RegCliente_Dia";
            this.lbl_RegCliente_Dia.Size = new System.Drawing.Size(33, 20);
            this.lbl_RegCliente_Dia.TabIndex = 14;
            this.lbl_RegCliente_Dia.Text = "Dia";
            this.lbl_RegCliente_Dia.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lbl_RegCliente_Mes
            // 
            this.lbl_RegCliente_Mes.AutoSize = true;
            this.lbl_RegCliente_Mes.Location = new System.Drawing.Point(424, 261);
            this.lbl_RegCliente_Mes.Name = "lbl_RegCliente_Mes";
            this.lbl_RegCliente_Mes.Size = new System.Drawing.Size(39, 20);
            this.lbl_RegCliente_Mes.TabIndex = 15;
            this.lbl_RegCliente_Mes.Text = "Mes";
            // 
            // lbl_RegCliente_Ano
            // 
            this.lbl_RegCliente_Ano.AutoSize = true;
            this.lbl_RegCliente_Ano.Location = new System.Drawing.Point(514, 261);
            this.lbl_RegCliente_Ano.Name = "lbl_RegCliente_Ano";
            this.lbl_RegCliente_Ano.Size = new System.Drawing.Size(38, 20);
            this.lbl_RegCliente_Ano.TabIndex = 16;
            this.lbl_RegCliente_Ano.Text = "Año";
            // 
            // txtbx_RegCliente_dia
            // 
            this.txtbx_RegCliente_dia.Location = new System.Drawing.Point(320, 285);
            this.txtbx_RegCliente_dia.Name = "txtbx_RegCliente_dia";
            this.txtbx_RegCliente_dia.Size = new System.Drawing.Size(73, 26);
            this.txtbx_RegCliente_dia.TabIndex = 17;
            // 
            // txtbx_RegCliente_mes
            // 
            this.txtbx_RegCliente_mes.Location = new System.Drawing.Point(408, 285);
            this.txtbx_RegCliente_mes.Name = "txtbx_RegCliente_mes";
            this.txtbx_RegCliente_mes.Size = new System.Drawing.Size(73, 26);
            this.txtbx_RegCliente_mes.TabIndex = 18;
            // 
            // txtbx_RegCliente_ano
            // 
            this.txtbx_RegCliente_ano.Location = new System.Drawing.Point(494, 285);
            this.txtbx_RegCliente_ano.Name = "txtbx_RegCliente_ano";
            this.txtbx_RegCliente_ano.Size = new System.Drawing.Size(73, 26);
            this.txtbx_RegCliente_ano.TabIndex = 19;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbx_RegCliente_ano);
            this.Controls.Add(this.txtbx_RegCliente_mes);
            this.Controls.Add(this.txtbx_RegCliente_dia);
            this.Controls.Add(this.lbl_RegCliente_Ano);
            this.Controls.Add(this.lbl_RegCliente_Mes);
            this.Controls.Add(this.lbl_RegCliente_Dia);
            this.Controls.Add(this.btn_RegCliente_Cancelar);
            this.Controls.Add(this.btn_RegCliente_Agregar);
            this.Controls.Add(this.txtbx_RegCliente_genero);
            this.Controls.Add(this.txtbx_RegCliente_2Ap);
            this.Controls.Add(this.txtbx_RegCliente_1Ap);
            this.Controls.Add(this.txtbx_RegCliente_Nombre);
            this.Controls.Add(this.txtbx_RegCliente_id);
            this.Controls.Add(this.lbl_RegCliente_Genero);
            this.Controls.Add(this.lbl_RegCliente_FechaNac);
            this.Controls.Add(this.lbl_RegCliente_2Apellido);
            this.Controls.Add(this.lbl_RegCliente_1Apellido);
            this.Controls.Add(this.lbl_RegCliente_Nombre);
            this.Controls.Add(this.lbl_RegCliente_id);
            this.Controls.Add(this.lbl_RegCliente_Titulo);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_RegCliente_Titulo;
        private System.Windows.Forms.Label lbl_RegCliente_id;
        private System.Windows.Forms.Label lbl_RegCliente_Nombre;
        private System.Windows.Forms.Label lbl_RegCliente_1Apellido;
        private System.Windows.Forms.Label lbl_RegCliente_2Apellido;
        private System.Windows.Forms.Label lbl_RegCliente_FechaNac;
        private System.Windows.Forms.Label lbl_RegCliente_Genero;
        private System.Windows.Forms.TextBox txtbx_RegCliente_id;
        private System.Windows.Forms.TextBox txtbx_RegCliente_Nombre;
        private System.Windows.Forms.TextBox txtbx_RegCliente_1Ap;
        private System.Windows.Forms.TextBox txtbx_RegCliente_2Ap;
        private System.Windows.Forms.TextBox txtbx_RegCliente_genero;
        private System.Windows.Forms.Button btn_RegCliente_Agregar;
        private System.Windows.Forms.Button btn_RegCliente_Cancelar;
        private System.Windows.Forms.Label lbl_RegCliente_Dia;
        private System.Windows.Forms.Label lbl_RegCliente_Mes;
        private System.Windows.Forms.Label lbl_RegCliente_Ano;
        private System.Windows.Forms.TextBox txtbx_RegCliente_dia;
        private System.Windows.Forms.TextBox txtbx_RegCliente_mes;
        private System.Windows.Forms.TextBox txtbx_RegCliente_ano;
    }
}