﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormConsultarClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_ConsultarCliente = new System.Windows.Forms.DataGridView();
            this.btn_ConsultarCliente = new System.Windows.Forms.Button();
            this.lbl_ConsultarCliente = new System.Windows.Forms.Label();
            this.Identificador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Primer_Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Segundo_Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fecha_Nac = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Genero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_ConsultarCliente
            // 
            this.dgv_ConsultarCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ConsultarCliente.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Identificador,
            this.Nombre,
            this.Primer_Apellido,
            this.Segundo_Apellido,
            this.Fecha_Nac,
            this.Genero});
            this.dgv_ConsultarCliente.Location = new System.Drawing.Point(12, 84);
            this.dgv_ConsultarCliente.Name = "dgv_ConsultarCliente";
            this.dgv_ConsultarCliente.RowHeadersWidth = 62;
            this.dgv_ConsultarCliente.RowTemplate.Height = 28;
            this.dgv_ConsultarCliente.Size = new System.Drawing.Size(776, 238);
            this.dgv_ConsultarCliente.TabIndex = 0;
            // 
            // btn_ConsultarCliente
            // 
            this.btn_ConsultarCliente.Location = new System.Drawing.Point(592, 361);
            this.btn_ConsultarCliente.Name = "btn_ConsultarCliente";
            this.btn_ConsultarCliente.Size = new System.Drawing.Size(100, 37);
            this.btn_ConsultarCliente.TabIndex = 1;
            this.btn_ConsultarCliente.Text = "Salir";
            this.btn_ConsultarCliente.UseVisualStyleBackColor = true;
            this.btn_ConsultarCliente.Click += new System.EventHandler(this.btn_ConsultarCliente_Click);
            // 
            // lbl_ConsultarCliente
            // 
            this.lbl_ConsultarCliente.AutoSize = true;
            this.lbl_ConsultarCliente.Location = new System.Drawing.Point(341, 35);
            this.lbl_ConsultarCliente.Name = "lbl_ConsultarCliente";
            this.lbl_ConsultarCliente.Size = new System.Drawing.Size(147, 20);
            this.lbl_ConsultarCliente.TabIndex = 2;
            this.lbl_ConsultarCliente.Text = "Consulta de Cliente";
            // 
            // Identificador
            // 
            this.Identificador.HeaderText = "Identificador";
            this.Identificador.MinimumWidth = 8;
            this.Identificador.Name = "Identificador";
            this.Identificador.Width = 150;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.MinimumWidth = 8;
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 150;
            // 
            // Primer_Apellido
            // 
            this.Primer_Apellido.HeaderText = "Primer_Apellido";
            this.Primer_Apellido.MinimumWidth = 8;
            this.Primer_Apellido.Name = "Primer_Apellido";
            this.Primer_Apellido.Width = 150;
            // 
            // Segundo_Apellido
            // 
            this.Segundo_Apellido.HeaderText = "Segundo_Apellido";
            this.Segundo_Apellido.MinimumWidth = 8;
            this.Segundo_Apellido.Name = "Segundo_Apellido";
            this.Segundo_Apellido.Width = 150;
            // 
            // Fecha_Nac
            // 
            this.Fecha_Nac.HeaderText = "Fecha_Nac";
            this.Fecha_Nac.MinimumWidth = 8;
            this.Fecha_Nac.Name = "Fecha_Nac";
            this.Fecha_Nac.Width = 150;
            // 
            // Genero
            // 
            this.Genero.HeaderText = "Genero";
            this.Genero.MinimumWidth = 8;
            this.Genero.Name = "Genero";
            this.Genero.Width = 150;
            // 
            // FormConsultarClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_ConsultarCliente);
            this.Controls.Add(this.btn_ConsultarCliente);
            this.Controls.Add(this.dgv_ConsultarCliente);
            this.Name = "FormConsultarClientes";
            this.Text = "FormConsultarClientes";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarCliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_ConsultarCliente;
        private System.Windows.Forms.Button btn_ConsultarCliente;
        private System.Windows.Forms.Label lbl_ConsultarCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Identificador;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Primer_Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Segundo_Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha_Nac;
        private System.Windows.Forms.DataGridViewTextBoxColumn Genero;
    }
}