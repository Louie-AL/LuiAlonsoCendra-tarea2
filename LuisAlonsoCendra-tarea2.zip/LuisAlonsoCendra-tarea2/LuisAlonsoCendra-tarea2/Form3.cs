﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btn_RegCliente_Cancelar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void btn_RegCliente_Agregar_Click(object sender, EventArgs e)
        {
            try { 
            bool duplicadoCliente = false;

                Variables.id_Cliente = txtbx_RegCliente_id.Text;

                for (int j_cc = 0; j_cc < Variables.contadorCliente; j_cc++)
                {
                    if (Variables.id_Cliente == Variables.arregloCliente[j_cc].idCliente)
                    {
                        duplicadoCliente = true;
                    }
                }

                if (duplicadoCliente)
                {
                    MessageBox.Show("Identificador repetido. Por favor, ingrese un id valido.");
                    return;
                }

                Variables.nombre_Cliente = txtbx_RegCliente_Nombre.Text;
                Variables.primer_ApellidoCliente = txtbx_RegCliente_1Ap.Text;
                Variables.segundo_ApellidoCliente = txtbx_RegCliente_2Ap.Text;
                Variables.dia = int.Parse(txtbx_RegCliente_dia.Text);
                Variables.mes = int.Parse(txtbx_RegCliente_mes.Text);
                Variables.ano = int.Parse(txtbx_RegCliente_ano.Text);
                Variables.genero_Cliente = txtbx_RegCliente_genero.Text[0];

                Variables.arregloCliente[Variables.contadorCliente] = new Cls_Cliente();
                Variables.arregloCliente[Variables.contadorCliente].idCliente = Variables.id_Cliente;
                Variables.arregloCliente[Variables.contadorCliente].nombreCliente = Variables.nombre_Cliente;
                Variables.arregloCliente[Variables.contadorCliente].primerApellidoCliente = Variables.primer_ApellidoCliente;
                Variables.arregloCliente[Variables.contadorCliente].segundoApellidoCliente = Variables.segundo_ApellidoCliente;
                Variables.arregloCliente[Variables.contadorCliente].nacimientoCliente = new DateTime(Variables.ano, Variables.mes, Variables.dia);
                Variables.arregloCliente[Variables.contadorCliente].generoCliente = Variables.genero_Cliente;

                Variables.contadorCliente = Variables.contadorCliente + 1;


                //Limpiar Variables
                Variables.id_Cliente = null;
                Variables.nombre_Cliente = null;
                Variables.primer_ApellidoCliente = null;
                Variables.segundo_ApellidoCliente = null;
                Variables.dia = 0;
                Variables.mes = 0;
                Variables.ano = 0;
                Variables.nacimiento_Cliente = default(DateTime);

                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error. Volviendo al menu principal.");
                this.Hide();
                Form1 frm = new Form1();
                frm.ShowDialog();
                return;
            }

        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }
    }
}
