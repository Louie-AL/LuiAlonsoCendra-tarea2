﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormConsultarTipoVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_ConsultarTipoV = new System.Windows.Forms.DataGridView();
            this.btn_ConsultarTipoV = new System.Windows.Forms.Button();
            this.lbl_ConsultarTipoV = new System.Windows.Forms.Label();
            this.Identificador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarTipoV)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_ConsultarTipoV
            // 
            this.dgv_ConsultarTipoV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ConsultarTipoV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Identificador,
            this.Descripcion,
            this.Estado});
            this.dgv_ConsultarTipoV.Location = new System.Drawing.Point(12, 100);
            this.dgv_ConsultarTipoV.Name = "dgv_ConsultarTipoV";
            this.dgv_ConsultarTipoV.RowHeadersWidth = 62;
            this.dgv_ConsultarTipoV.RowTemplate.Height = 28;
            this.dgv_ConsultarTipoV.Size = new System.Drawing.Size(776, 244);
            this.dgv_ConsultarTipoV.TabIndex = 0;
            // 
            // btn_ConsultarTipoV
            // 
            this.btn_ConsultarTipoV.Location = new System.Drawing.Point(633, 372);
            this.btn_ConsultarTipoV.Name = "btn_ConsultarTipoV";
            this.btn_ConsultarTipoV.Size = new System.Drawing.Size(100, 38);
            this.btn_ConsultarTipoV.TabIndex = 1;
            this.btn_ConsultarTipoV.Text = "Salir";
            this.btn_ConsultarTipoV.UseVisualStyleBackColor = true;
            this.btn_ConsultarTipoV.Click += new System.EventHandler(this.btn_ConsultarTipoV_Click);
            // 
            // lbl_ConsultarTipoV
            // 
            this.lbl_ConsultarTipoV.AutoSize = true;
            this.lbl_ConsultarTipoV.Location = new System.Drawing.Point(323, 37);
            this.lbl_ConsultarTipoV.Name = "lbl_ConsultarTipoV";
            this.lbl_ConsultarTipoV.Size = new System.Drawing.Size(198, 20);
            this.lbl_ConsultarTipoV.TabIndex = 2;
            this.lbl_ConsultarTipoV.Text = "Consultar Tipo de Vehiculo";
            // 
            // Identificador
            // 
            this.Identificador.HeaderText = "Identificador";
            this.Identificador.MinimumWidth = 8;
            this.Identificador.Name = "Identificador";
            this.Identificador.Width = 150;
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Descripcion";
            this.Descripcion.MinimumWidth = 8;
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.Width = 150;
            // 
            // Estado
            // 
            this.Estado.HeaderText = "Estado";
            this.Estado.MinimumWidth = 8;
            this.Estado.Name = "Estado";
            this.Estado.Width = 150;
            // 
            // FormConsultarTipoVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_ConsultarTipoV);
            this.Controls.Add(this.btn_ConsultarTipoV);
            this.Controls.Add(this.dgv_ConsultarTipoV);
            this.Name = "FormConsultarTipoVehiculo";
            this.Text = "FormConsultarTipoVehiculo";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ConsultarTipoV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_ConsultarTipoV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Identificador;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado;
        private System.Windows.Forms.Button btn_ConsultarTipoV;
        private System.Windows.Forms.Label lbl_ConsultarTipoV;
    }
}