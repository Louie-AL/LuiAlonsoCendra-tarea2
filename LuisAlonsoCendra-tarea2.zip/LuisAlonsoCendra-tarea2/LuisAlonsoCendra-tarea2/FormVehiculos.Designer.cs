﻿namespace LuisAlonsoCendra_tarea2
{
    partial class FormVehiculos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_RegVehiculo_Titulo = new System.Windows.Forms.Label();
            this.lbl_RegVehiculo_id = new System.Windows.Forms.Label();
            this.lbl_RegVehiculo_Marca = new System.Windows.Forms.Label();
            this.lbl_RegVehiculo_Modelo = new System.Windows.Forms.Label();
            this.lbl_RegVehiculo_idTipo = new System.Windows.Forms.Label();
            this.lbl_RegVehiculo_Costo = new System.Windows.Forms.Label();
            this.lbl_RegVehiculo_Km = new System.Windows.Forms.Label();
            this.txtbx_RegVehiculo_id = new System.Windows.Forms.TextBox();
            this.txtbx_RegVehiculo_modelo = new System.Windows.Forms.TextBox();
            this.txtbx_RegVehiculo_idTipoV = new System.Windows.Forms.TextBox();
            this.txtbx_RegVehiculo_Costo = new System.Windows.Forms.TextBox();
            this.txtbx_RegVehiculo_Km = new System.Windows.Forms.TextBox();
            this.txtbx_RegVehiculo_marca = new System.Windows.Forms.TextBox();
            this.btn_RegVehiculo_Agregar = new System.Windows.Forms.Button();
            this.btn_RegVehiculo_Cancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_RegVehiculo_Titulo
            // 
            this.lbl_RegVehiculo_Titulo.AutoSize = true;
            this.lbl_RegVehiculo_Titulo.Location = new System.Drawing.Point(374, 65);
            this.lbl_RegVehiculo_Titulo.Name = "lbl_RegVehiculo_Titulo";
            this.lbl_RegVehiculo_Titulo.Size = new System.Drawing.Size(164, 20);
            this.lbl_RegVehiculo_Titulo.TabIndex = 0;
            this.lbl_RegVehiculo_Titulo.Text = "Registro de Vehiculos";
            // 
            // lbl_RegVehiculo_id
            // 
            this.lbl_RegVehiculo_id.AutoSize = true;
            this.lbl_RegVehiculo_id.Location = new System.Drawing.Point(70, 126);
            this.lbl_RegVehiculo_id.Name = "lbl_RegVehiculo_id";
            this.lbl_RegVehiculo_id.Size = new System.Drawing.Size(97, 20);
            this.lbl_RegVehiculo_id.TabIndex = 1;
            this.lbl_RegVehiculo_id.Text = "Identificador";
            // 
            // lbl_RegVehiculo_Marca
            // 
            this.lbl_RegVehiculo_Marca.AutoSize = true;
            this.lbl_RegVehiculo_Marca.Location = new System.Drawing.Point(70, 171);
            this.lbl_RegVehiculo_Marca.Name = "lbl_RegVehiculo_Marca";
            this.lbl_RegVehiculo_Marca.Size = new System.Drawing.Size(53, 20);
            this.lbl_RegVehiculo_Marca.TabIndex = 2;
            this.lbl_RegVehiculo_Marca.Text = "Marca";
            this.lbl_RegVehiculo_Marca.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbl_RegVehiculo_Modelo
            // 
            this.lbl_RegVehiculo_Modelo.AutoSize = true;
            this.lbl_RegVehiculo_Modelo.Location = new System.Drawing.Point(70, 221);
            this.lbl_RegVehiculo_Modelo.Name = "lbl_RegVehiculo_Modelo";
            this.lbl_RegVehiculo_Modelo.Size = new System.Drawing.Size(61, 20);
            this.lbl_RegVehiculo_Modelo.TabIndex = 3;
            this.lbl_RegVehiculo_Modelo.Text = "Modelo";
            // 
            // lbl_RegVehiculo_idTipo
            // 
            this.lbl_RegVehiculo_idTipo.AutoSize = true;
            this.lbl_RegVehiculo_idTipo.Location = new System.Drawing.Point(70, 268);
            this.lbl_RegVehiculo_idTipo.Name = "lbl_RegVehiculo_idTipo";
            this.lbl_RegVehiculo_idTipo.Size = new System.Drawing.Size(243, 20);
            this.lbl_RegVehiculo_idTipo.TabIndex = 4;
            this.lbl_RegVehiculo_idTipo.Text = "Identificador del Tipo de Vehiculo";
            // 
            // lbl_RegVehiculo_Costo
            // 
            this.lbl_RegVehiculo_Costo.AutoSize = true;
            this.lbl_RegVehiculo_Costo.Location = new System.Drawing.Point(70, 314);
            this.lbl_RegVehiculo_Costo.Name = "lbl_RegVehiculo_Costo";
            this.lbl_RegVehiculo_Costo.Size = new System.Drawing.Size(181, 20);
            this.lbl_RegVehiculo_Costo.TabIndex = 5;
            this.lbl_RegVehiculo_Costo.Text = "Costo de Alquiler por dia";
            // 
            // lbl_RegVehiculo_Km
            // 
            this.lbl_RegVehiculo_Km.AutoSize = true;
            this.lbl_RegVehiculo_Km.Location = new System.Drawing.Point(70, 360);
            this.lbl_RegVehiculo_Km.Name = "lbl_RegVehiculo_Km";
            this.lbl_RegVehiculo_Km.Size = new System.Drawing.Size(87, 20);
            this.lbl_RegVehiculo_Km.TabIndex = 6;
            this.lbl_RegVehiculo_Km.Text = "Kilometraje";
            // 
            // txtbx_RegVehiculo_id
            // 
            this.txtbx_RegVehiculo_id.Location = new System.Drawing.Point(327, 126);
            this.txtbx_RegVehiculo_id.Name = "txtbx_RegVehiculo_id";
            this.txtbx_RegVehiculo_id.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegVehiculo_id.TabIndex = 7;
            // 
            // txtbx_RegVehiculo_modelo
            // 
            this.txtbx_RegVehiculo_modelo.Location = new System.Drawing.Point(327, 218);
            this.txtbx_RegVehiculo_modelo.Name = "txtbx_RegVehiculo_modelo";
            this.txtbx_RegVehiculo_modelo.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegVehiculo_modelo.TabIndex = 8;
            // 
            // txtbx_RegVehiculo_idTipoV
            // 
            this.txtbx_RegVehiculo_idTipoV.Location = new System.Drawing.Point(327, 265);
            this.txtbx_RegVehiculo_idTipoV.Name = "txtbx_RegVehiculo_idTipoV";
            this.txtbx_RegVehiculo_idTipoV.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegVehiculo_idTipoV.TabIndex = 9;
            // 
            // txtbx_RegVehiculo_Costo
            // 
            this.txtbx_RegVehiculo_Costo.Location = new System.Drawing.Point(327, 311);
            this.txtbx_RegVehiculo_Costo.Name = "txtbx_RegVehiculo_Costo";
            this.txtbx_RegVehiculo_Costo.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegVehiculo_Costo.TabIndex = 10;
            // 
            // txtbx_RegVehiculo_Km
            // 
            this.txtbx_RegVehiculo_Km.Location = new System.Drawing.Point(327, 357);
            this.txtbx_RegVehiculo_Km.Name = "txtbx_RegVehiculo_Km";
            this.txtbx_RegVehiculo_Km.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegVehiculo_Km.TabIndex = 11;
            // 
            // txtbx_RegVehiculo_marca
            // 
            this.txtbx_RegVehiculo_marca.Location = new System.Drawing.Point(327, 168);
            this.txtbx_RegVehiculo_marca.Name = "txtbx_RegVehiculo_marca";
            this.txtbx_RegVehiculo_marca.Size = new System.Drawing.Size(275, 26);
            this.txtbx_RegVehiculo_marca.TabIndex = 12;
            // 
            // btn_RegVehiculo_Agregar
            // 
            this.btn_RegVehiculo_Agregar.Location = new System.Drawing.Point(662, 168);
            this.btn_RegVehiculo_Agregar.Name = "btn_RegVehiculo_Agregar";
            this.btn_RegVehiculo_Agregar.Size = new System.Drawing.Size(86, 35);
            this.btn_RegVehiculo_Agregar.TabIndex = 13;
            this.btn_RegVehiculo_Agregar.Text = "Agregar";
            this.btn_RegVehiculo_Agregar.UseVisualStyleBackColor = true;
            this.btn_RegVehiculo_Agregar.Click += new System.EventHandler(this.btn_RegVehiculo_Agregar_Click);
            // 
            // btn_RegVehiculo_Cancelar
            // 
            this.btn_RegVehiculo_Cancelar.Location = new System.Drawing.Point(662, 311);
            this.btn_RegVehiculo_Cancelar.Name = "btn_RegVehiculo_Cancelar";
            this.btn_RegVehiculo_Cancelar.Size = new System.Drawing.Size(86, 35);
            this.btn_RegVehiculo_Cancelar.TabIndex = 14;
            this.btn_RegVehiculo_Cancelar.Text = "Cancelar";
            this.btn_RegVehiculo_Cancelar.UseVisualStyleBackColor = true;
            this.btn_RegVehiculo_Cancelar.Click += new System.EventHandler(this.btn_RegVehiculo_Cancelar_Click);
            // 
            // FormVehiculos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_RegVehiculo_Cancelar);
            this.Controls.Add(this.btn_RegVehiculo_Agregar);
            this.Controls.Add(this.txtbx_RegVehiculo_marca);
            this.Controls.Add(this.txtbx_RegVehiculo_Km);
            this.Controls.Add(this.txtbx_RegVehiculo_Costo);
            this.Controls.Add(this.txtbx_RegVehiculo_idTipoV);
            this.Controls.Add(this.txtbx_RegVehiculo_modelo);
            this.Controls.Add(this.txtbx_RegVehiculo_id);
            this.Controls.Add(this.lbl_RegVehiculo_Km);
            this.Controls.Add(this.lbl_RegVehiculo_Costo);
            this.Controls.Add(this.lbl_RegVehiculo_idTipo);
            this.Controls.Add(this.lbl_RegVehiculo_Modelo);
            this.Controls.Add(this.lbl_RegVehiculo_Marca);
            this.Controls.Add(this.lbl_RegVehiculo_id);
            this.Controls.Add(this.lbl_RegVehiculo_Titulo);
            this.Name = "FormVehiculos";
            this.Text = "FormVehiculos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_RegVehiculo_Titulo;
        private System.Windows.Forms.Label lbl_RegVehiculo_id;
        private System.Windows.Forms.Label lbl_RegVehiculo_Marca;
        private System.Windows.Forms.Label lbl_RegVehiculo_Modelo;
        private System.Windows.Forms.Label lbl_RegVehiculo_idTipo;
        private System.Windows.Forms.Label lbl_RegVehiculo_Costo;
        private System.Windows.Forms.Label lbl_RegVehiculo_Km;
        private System.Windows.Forms.TextBox txtbx_RegVehiculo_id;
        private System.Windows.Forms.TextBox txtbx_RegVehiculo_modelo;
        private System.Windows.Forms.TextBox txtbx_RegVehiculo_idTipoV;
        private System.Windows.Forms.TextBox txtbx_RegVehiculo_Costo;
        private System.Windows.Forms.TextBox txtbx_RegVehiculo_Km;
        private System.Windows.Forms.TextBox txtbx_RegVehiculo_marca;
        private System.Windows.Forms.Button btn_RegVehiculo_Agregar;
        private System.Windows.Forms.Button btn_RegVehiculo_Cancelar;
    }
}