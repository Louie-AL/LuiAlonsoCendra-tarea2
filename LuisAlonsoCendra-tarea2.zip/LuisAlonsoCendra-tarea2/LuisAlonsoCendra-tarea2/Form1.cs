﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 forma2 = new Form2();
            forma2.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 forma3 = new Form3();
            forma3.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTipoVehiculo formaTipoVehiculo = new FormTipoVehiculo();
            formaTipoVehiculo.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormVehiculos formaVehiculo = new FormVehiculos();
            formaVehiculo.ShowDialog();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("El programa procede a terminar.");
            Application.Exit();
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }

        private void btnRegCobertura_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormCoberturas formaCoberturas = new FormCoberturas();
            formaCoberturas.ShowDialog();
 
        }

        private void btnConSucursal_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormConsultarSucursal formaConsultaSucursal = new FormConsultarSucursal();
            formaConsultaSucursal.ShowDialog();

        }

        private void btnConCliente_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormConsultarClientes formaConsultaCliente = new FormConsultarClientes();
            formaConsultaCliente.ShowDialog();
        }

        private void btnConTipoVehiculo_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormConsultarTipoVehiculo formaConsultarTipoV = new FormConsultarTipoVehiculo();
            formaConsultarTipoV.ShowDialog();
        }

        private void btnConVehiculo_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormConsultarVehiculo formaConsultarVehiculo = new FormConsultarVehiculo();
            formaConsultarVehiculo.ShowDialog();
        }

        private void btnConCobertura_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormConsultarCoberturas formaConsultarCobertura = new FormConsultarCoberturas();
            formaConsultarCobertura.ShowDialog();
        }

        private void btnRegVehXSuc_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormVehiculoPorSucursal formaVXP = new FormVehiculoPorSucursal();
            formaVXP.ShowDialog();
        }
    }
}
