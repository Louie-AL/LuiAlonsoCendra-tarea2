﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormConsultarClientes : Form
    {
        public FormConsultarClientes()
        {
            InitializeComponent();

            for (int i_cc = 0; i_cc < Variables.contadorCliente; i_cc++)
            {
                dgv_ConsultarCliente.Rows.Add(Variables.arregloCliente[i_cc].idCliente, Variables.arregloCliente[i_cc].nombreCliente, Variables.arregloCliente[i_cc].primerApellidoCliente, Variables.arregloCliente[i_cc].segundoApellidoCliente, Variables.arregloCliente[i_cc].nacimientoCliente.ToString("dd-MM-yyyy"), Variables.arregloCliente[i_cc].generoCliente);

            }
        }

        private void btn_ConsultarCliente_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }
    }
}
