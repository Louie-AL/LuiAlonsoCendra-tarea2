﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormConsultarCoberturas : Form
    {
        public FormConsultarCoberturas()
        {
            InitializeComponent();
            for (int i_cob = 0; i_cob < Variables.contadorCoberturas; i_cob++)
            {
                dgv_ConsultarCobertura.Rows.Add(Variables.arregloCobertura[i_cob].idCobertura, Variables.arregloCobertura[i_cob].descripcionCobertura, Variables.arregloCobertura[i_cob].idTipoVehiculo.idTipoVehiculo, Variables.arregloCobertura[i_cob].estadoCobertura, Variables.arregloCobertura[i_cob].montoCobertura);

            }
        }

        private void btn_ConsultarCobertura_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }
    }
}
