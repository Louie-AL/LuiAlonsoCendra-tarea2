﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormVehiculos : Form
    {
        public FormVehiculos()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btn_RegVehiculo_Cancelar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void btn_RegVehiculo_Agregar_Click(object sender, EventArgs e)
        {
            try {     
            bool duplicadoV = false;

                Variables.placa_Vehiculo = txtbx_RegVehiculo_id.Text;

                for (int j_v = 0; j_v < Variables.contadorVehiculo; j_v++)
                {
                    if (Variables.placa_Vehiculo == Variables.arregloVehiculo[j_v].idPlacaVehiculo)
                    {
                        duplicadoV = true;
                    }
                }

                if (duplicadoV)
                {
                    MessageBox.Show("Placa repetida. Por favor, ingrese una placa valida.");
                    return;
                }

                Variables.marca_Vehiculo = txtbx_RegVehiculo_marca.Text;
                Variables.modelo_Vehiculo = txtbx_RegVehiculo_modelo.Text;
                Variables.IdTipo_Vehiculo_int = txtbx_RegVehiculo_idTipoV.Text;
                Variables.costo_Vehiculo = int.Parse(txtbx_RegVehiculo_Costo.Text);
                Variables.kilometraje_Vehiculo = int.Parse(txtbx_RegVehiculo_Km.Text);

                Variables.arregloVehiculo[Variables.contadorVehiculo] = new Cls_Vehiculo();
                Variables.arregloVehiculo[Variables.contadorVehiculo].idPlacaVehiculo = Variables.placa_Vehiculo;
                Variables.arregloVehiculo[Variables.contadorVehiculo].marcaVehiculo = Variables.marca_Vehiculo;
                Variables.arregloVehiculo[Variables.contadorVehiculo].modeloVehiculo = Variables.modelo_Vehiculo;
                Variables.arregloVehiculo[Variables.contadorVehiculo].idTipoVehiculo = new Cls_TipoVehiculo();
                Variables.arregloVehiculo[Variables.contadorVehiculo].costoAlquilerDia = Variables.costo_Vehiculo;
                Variables.arregloVehiculo[Variables.contadorVehiculo].kilometraje = Variables.kilometraje_Vehiculo;

                Variables.contadorVehiculo = Variables.contadorVehiculo + 1;

                //Limpiar Variables
                Variables.placa_Vehiculo = null;
                Variables.marca_Vehiculo = null;
                Variables.modelo_Vehiculo = null;
                Variables.IdTipo_Vehiculo_int = null;
                Variables.IdTipo_Vehiculo_obj = new Cls_TipoVehiculo();
                Variables.costo_Vehiculo = 0;
                Variables.kilometraje_Vehiculo = 0;

                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error. Volviendo al menu principal.");
                this.Hide();
                Form1 frm = new Form1();
                frm.ShowDialog();
                return;
            }
        }

        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }
    }
}
