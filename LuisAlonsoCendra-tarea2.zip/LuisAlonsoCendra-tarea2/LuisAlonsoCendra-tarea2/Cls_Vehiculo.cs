﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuisAlonsoCendra_tarea2
{

    public class Cls_Vehiculo
    {
        public string idPlacaVehiculo;
        public string marcaVehiculo;
        public string modeloVehiculo;
        public Cls_TipoVehiculo idTipoVehiculo;
        public int costoAlquilerDia;
        public int kilometraje;

        public Cls_Vehiculo(string idPlacaVehiculo, string marcaVehiculo, string modeloVehiculo, Cls_TipoVehiculo idTipoVehiculo, int costoAlquilerDia, int kilometraje)
        {
            this.idPlacaVehiculo = idPlacaVehiculo ?? throw new ArgumentNullException(nameof(idPlacaVehiculo));
            this.marcaVehiculo = marcaVehiculo ?? throw new ArgumentNullException(nameof(marcaVehiculo));
            this.modeloVehiculo = modeloVehiculo ?? throw new ArgumentNullException(nameof(modeloVehiculo));
            this.idTipoVehiculo = idTipoVehiculo ?? throw new ArgumentNullException(nameof(idTipoVehiculo));
            this.costoAlquilerDia = costoAlquilerDia;
            this.kilometraje = kilometraje;
        }

        public Cls_Vehiculo()
        {
        }
    }
}
