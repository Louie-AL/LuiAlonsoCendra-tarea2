﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormConsultarTipoVehiculo : Form
    {
        public FormConsultarTipoVehiculo()
        {
            InitializeComponent();

            for (int i_tv = 0; i_tv < Variables.contadorTipoV; i_tv++)
            {
                dgv_ConsultarTipoV.Rows.Add(Variables.arregloTipoVehiculo[i_tv].idTipoVehiculo, Variables.arregloTipoVehiculo[i_tv].descripcionTipoVehiculo, Variables.arregloTipoVehiculo[i_tv].estadoTipoVehiculo.ToString());

            }
        }

        private void btn_ConsultarTipoV_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }
    }
}
