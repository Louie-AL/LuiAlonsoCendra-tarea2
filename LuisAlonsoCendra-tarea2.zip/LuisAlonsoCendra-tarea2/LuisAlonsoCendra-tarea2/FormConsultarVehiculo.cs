﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormConsultarVehiculo : Form
    {
        public FormConsultarVehiculo()
        {
            InitializeComponent();

            for (int i_v = 0; i_v < Variables.contadorVehiculo; i_v++)
            {
                dgv_ConsultarVehiculo.Rows.Add(Variables.arregloVehiculo[i_v].idPlacaVehiculo, Variables.arregloVehiculo[i_v].marcaVehiculo, Variables.arregloVehiculo[i_v].modeloVehiculo, Variables.arregloVehiculo[i_v].idTipoVehiculo.descripcionTipoVehiculo, Variables.arregloVehiculo[i_v].costoAlquilerDia, Variables.arregloVehiculo[i_v].kilometraje);

            }
        }

        private void btn_ConsultarVehiculo_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }
    }
}
