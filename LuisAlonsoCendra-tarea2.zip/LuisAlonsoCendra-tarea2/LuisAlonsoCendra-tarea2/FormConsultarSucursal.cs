﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuisAlonsoCendra_tarea2
{
    public partial class FormConsultarSucursal : Form
    {
        public FormConsultarSucursal()
        {
            InitializeComponent();

            for(int i_cs = 0; i_cs < Variables.contadorSucursales; i_cs++)
            {
                dgv_ConsultarSucursal.Rows.Add(Variables.arregloSucursales[i_cs].idSucursal, Variables.arregloSucursales[i_cs].nombreSucursal, Variables.arregloSucursales[i_cs].direccionSucursal, Variables.arregloSucursales[i_cs].estadoSucursal.ToString(), Variables.arregloSucursales[i_cs].telefonoSucursal);
                
            }
        }

        private void btn_ConsultarSucursal_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm = new Form1();
            frm.ShowDialog();
        }
    }
}
