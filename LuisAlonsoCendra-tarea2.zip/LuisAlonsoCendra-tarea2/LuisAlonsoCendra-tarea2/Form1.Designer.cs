﻿namespace LuisAlonsoCendra_tarea2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnRegSucursal = new System.Windows.Forms.Button();
            this.btnRegCliente = new System.Windows.Forms.Button();
            this.btnRegTipoVehiculo = new System.Windows.Forms.Button();
            this.btnRegVehiculo = new System.Windows.Forms.Button();
            this.btnRegCobertura = new System.Windows.Forms.Button();
            this.btnConSucursal = new System.Windows.Forms.Button();
            this.btnConCliente = new System.Windows.Forms.Button();
            this.btnConTipoVehiculo = new System.Windows.Forms.Button();
            this.btnConVehiculo = new System.Windows.Forms.Button();
            this.btnConCobertura = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnRegVehXSuc = new System.Windows.Forms.Button();
            this.btnConVehXSuc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(275, 33);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(306, 20);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Sistema de informacion de RENTA-UNED";
            this.lblWelcome.Click += new System.EventHandler(this.lblWelcome_Click);
            // 
            // btnRegSucursal
            // 
            this.btnRegSucursal.Location = new System.Drawing.Point(153, 80);
            this.btnRegSucursal.Name = "btnRegSucursal";
            this.btnRegSucursal.Size = new System.Drawing.Size(275, 32);
            this.btnRegSucursal.TabIndex = 1;
            this.btnRegSucursal.Text = "Registrar Sucursal";
            this.btnRegSucursal.UseVisualStyleBackColor = true;
            this.btnRegSucursal.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRegCliente
            // 
            this.btnRegCliente.Location = new System.Drawing.Point(153, 132);
            this.btnRegCliente.Name = "btnRegCliente";
            this.btnRegCliente.Size = new System.Drawing.Size(275, 32);
            this.btnRegCliente.TabIndex = 2;
            this.btnRegCliente.Text = "Registrar Cliente";
            this.btnRegCliente.UseVisualStyleBackColor = true;
            this.btnRegCliente.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnRegTipoVehiculo
            // 
            this.btnRegTipoVehiculo.Location = new System.Drawing.Point(153, 188);
            this.btnRegTipoVehiculo.Name = "btnRegTipoVehiculo";
            this.btnRegTipoVehiculo.Size = new System.Drawing.Size(275, 32);
            this.btnRegTipoVehiculo.TabIndex = 3;
            this.btnRegTipoVehiculo.Text = "Registrar Tipo de Vehiculo";
            this.btnRegTipoVehiculo.UseVisualStyleBackColor = true;
            this.btnRegTipoVehiculo.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnRegVehiculo
            // 
            this.btnRegVehiculo.Location = new System.Drawing.Point(153, 237);
            this.btnRegVehiculo.Name = "btnRegVehiculo";
            this.btnRegVehiculo.Size = new System.Drawing.Size(275, 32);
            this.btnRegVehiculo.TabIndex = 4;
            this.btnRegVehiculo.Text = "Registrar Vehiculo";
            this.btnRegVehiculo.UseVisualStyleBackColor = true;
            this.btnRegVehiculo.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnRegCobertura
            // 
            this.btnRegCobertura.Location = new System.Drawing.Point(153, 284);
            this.btnRegCobertura.Name = "btnRegCobertura";
            this.btnRegCobertura.Size = new System.Drawing.Size(275, 32);
            this.btnRegCobertura.TabIndex = 5;
            this.btnRegCobertura.Text = "Registrar Cobertura";
            this.btnRegCobertura.UseVisualStyleBackColor = true;
            this.btnRegCobertura.Click += new System.EventHandler(this.btnRegCobertura_Click);
            // 
            // btnConSucursal
            // 
            this.btnConSucursal.Location = new System.Drawing.Point(474, 80);
            this.btnConSucursal.Name = "btnConSucursal";
            this.btnConSucursal.Size = new System.Drawing.Size(275, 32);
            this.btnConSucursal.TabIndex = 6;
            this.btnConSucursal.Text = "Consultar Sucursal";
            this.btnConSucursal.UseVisualStyleBackColor = true;
            this.btnConSucursal.Click += new System.EventHandler(this.btnConSucursal_Click);
            // 
            // btnConCliente
            // 
            this.btnConCliente.Location = new System.Drawing.Point(474, 132);
            this.btnConCliente.Name = "btnConCliente";
            this.btnConCliente.Size = new System.Drawing.Size(275, 32);
            this.btnConCliente.TabIndex = 7;
            this.btnConCliente.Text = "Consultar Cliente";
            this.btnConCliente.UseVisualStyleBackColor = true;
            this.btnConCliente.Click += new System.EventHandler(this.btnConCliente_Click);
            // 
            // btnConTipoVehiculo
            // 
            this.btnConTipoVehiculo.Location = new System.Drawing.Point(474, 188);
            this.btnConTipoVehiculo.Name = "btnConTipoVehiculo";
            this.btnConTipoVehiculo.Size = new System.Drawing.Size(275, 32);
            this.btnConTipoVehiculo.TabIndex = 8;
            this.btnConTipoVehiculo.Text = "Consultar Tipo de Vehiculo";
            this.btnConTipoVehiculo.UseVisualStyleBackColor = true;
            this.btnConTipoVehiculo.Click += new System.EventHandler(this.btnConTipoVehiculo_Click);
            // 
            // btnConVehiculo
            // 
            this.btnConVehiculo.Location = new System.Drawing.Point(474, 237);
            this.btnConVehiculo.Name = "btnConVehiculo";
            this.btnConVehiculo.Size = new System.Drawing.Size(275, 32);
            this.btnConVehiculo.TabIndex = 9;
            this.btnConVehiculo.Text = "Consultar Vehiculo";
            this.btnConVehiculo.UseVisualStyleBackColor = true;
            this.btnConVehiculo.Click += new System.EventHandler(this.btnConVehiculo_Click);
            // 
            // btnConCobertura
            // 
            this.btnConCobertura.Location = new System.Drawing.Point(474, 284);
            this.btnConCobertura.Name = "btnConCobertura";
            this.btnConCobertura.Size = new System.Drawing.Size(275, 32);
            this.btnConCobertura.TabIndex = 10;
            this.btnConCobertura.Text = "Consultar Cobertura";
            this.btnConCobertura.UseVisualStyleBackColor = true;
            this.btnConCobertura.Click += new System.EventHandler(this.btnConCobertura_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(347, 395);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(175, 32);
            this.btnSalir.TabIndex = 11;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnRegVehXSuc
            // 
            this.btnRegVehXSuc.Location = new System.Drawing.Point(153, 337);
            this.btnRegVehXSuc.Name = "btnRegVehXSuc";
            this.btnRegVehXSuc.Size = new System.Drawing.Size(275, 32);
            this.btnRegVehXSuc.TabIndex = 12;
            this.btnRegVehXSuc.Text = "Registrar Vehiculo por Sucursal";
            this.btnRegVehXSuc.UseVisualStyleBackColor = true;
            this.btnRegVehXSuc.Click += new System.EventHandler(this.btnRegVehXSuc_Click);
            // 
            // btnConVehXSuc
            // 
            this.btnConVehXSuc.Location = new System.Drawing.Point(474, 337);
            this.btnConVehXSuc.Name = "btnConVehXSuc";
            this.btnConVehXSuc.Size = new System.Drawing.Size(275, 32);
            this.btnConVehXSuc.TabIndex = 13;
            this.btnConVehXSuc.Text = "Consultar Vehiculo por Sucursal";
            this.btnConVehXSuc.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnConVehXSuc);
            this.Controls.Add(this.btnRegVehXSuc);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnConCobertura);
            this.Controls.Add(this.btnConVehiculo);
            this.Controls.Add(this.btnConTipoVehiculo);
            this.Controls.Add(this.btnConCliente);
            this.Controls.Add(this.btnConSucursal);
            this.Controls.Add(this.btnRegCobertura);
            this.Controls.Add(this.btnRegVehiculo);
            this.Controls.Add(this.btnRegTipoVehiculo);
            this.Controls.Add(this.btnRegCliente);
            this.Controls.Add(this.btnRegSucursal);
            this.Controls.Add(this.lblWelcome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnRegSucursal;
        private System.Windows.Forms.Button btnRegCliente;
        private System.Windows.Forms.Button btnRegTipoVehiculo;
        private System.Windows.Forms.Button btnRegVehiculo;
        private System.Windows.Forms.Button btnRegCobertura;
        private System.Windows.Forms.Button btnConSucursal;
        private System.Windows.Forms.Button btnConCliente;
        private System.Windows.Forms.Button btnConTipoVehiculo;
        private System.Windows.Forms.Button btnConVehiculo;
        private System.Windows.Forms.Button btnConCobertura;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnRegVehXSuc;
        private System.Windows.Forms.Button btnConVehXSuc;
    }
}

